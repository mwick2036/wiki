﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using DiaCumminsOrders.Domain;

namespace DiaCumminsOrders.Application.Interfaces
{
    public interface IDiaRepository
    {
        IDbSet<DiaOrder> DiaOrders { get; set; }
        void Save();
    }
}
