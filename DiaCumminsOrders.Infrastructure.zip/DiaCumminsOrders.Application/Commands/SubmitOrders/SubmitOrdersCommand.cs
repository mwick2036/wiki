﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiaCumminsOrders.Application.Interfaces;
using DiaCumminsOrders.Domain;

namespace DiaCumminsOrders.Application.Commands.SubmitOrders
{
    public class SubmitOrdersCommand : ISubmitOrdersCommand
    {
        private readonly IDiaRepository _diaRepository;
        private readonly ICumminsService _cummins;

        public SubmitOrdersCommand(IDiaRepository diaRepository, ICumminsService cummins)
        {
            _diaRepository = diaRepository;
            _cummins = cummins;
        }

        public void Execute()
        {
            // Get unsubmitted orders
            var diaOrders = _diaRepository.DiaOrders.ToArray();

            //var orderLineItemsByPo = _diaRepository.DiaOrders
            //    .Where(o => o.SubmitDate == null)
            //    .GroupBy(o => o.PoNumber)
            //    .ToDictionary(go => go.Key, go => go.ToList());

            for (var i = 0; i < diaOrders.Length; i++)
            {
                _cummins.SubmitOrder(ref diaOrders[i]);


                //for (var i = 0; i < diaOrder.LineItems.Count; i += _cummins.MaxLineItems)
                //{
                //    var cumminsPoNumber = $"{diaOrder.PoNumber}-{++poSuffix}";
                //    var orderBatch = diaOrder.LineItems.Take(_cummins.MaxLineItems).Skip(i).ToList();
                //    var success = _cummins.SubmitOrders(cumminsPoNumber, orderBatch);

                //    foreach (var order in orderBatch)
                //    {
                //        if (success)
                //        {
                //            order.CumminsPoNumber = cumminsPoNumber;
                //            order.SubmitDate = DateTime.Now;
                //        }
                //        else
                //        {
                //            if (order.Retries.HasValue)
                //            {
                //                order.LastRetryDate = DateTime.Now;
                //                order.Retries += 1;
                //            }
                //            else
                //            {
                //                order.Retries = 0;
                //            }
                //        }
                //    }
                //}
            }

            _diaRepository.Save();
        }
    }
}
