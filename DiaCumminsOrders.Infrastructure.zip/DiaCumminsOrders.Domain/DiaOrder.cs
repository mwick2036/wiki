﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace DiaCumminsOrders.Domain
{
    public class DiaOrderLineItem
    {
        public int Id { get; set; }

        [ForeignKey("DiaOrder")]
        public int DiaOrderId { get; set; }

        public string PartNumber { get; set; }
        public int Quantity { get; set; }
        public decimal UnitNetPrice { get; set; }
        public string CumminsPoNumber { get; set; }
        public DateTime? SubmitDate { get; set; }
        public DateTime? LastRetryDate { get; set; }
        public int? Retries { get; set; }

        public virtual DiaOrder DiaOrder { get; set; }
    }

    public class DiaOrder
    {
        public int Id { get; set; }
        public string DealerCode { get; set; }
        public string OrderType { get; set; }
        public string CountryCode { get; set; }
        public string ShipVia { get; set; }
        public string ShipToName { get; set; }
        public string PoNumber { get; set; }
        public int ServiceKey { get; set; }
        public virtual ICollection<DiaOrderLineItem> LineItems { get; set; }
    }
}
