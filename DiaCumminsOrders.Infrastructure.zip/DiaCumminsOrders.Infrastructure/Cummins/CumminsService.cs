﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using DiaCumminsOrders.Application.Interfaces;
using DiaCumminsOrders.Domain;
using DiaCumminsOrders.Infrastructure.Network;

namespace DiaCumminsOrders.Infrastructure.Cummins
{
    public class CumminsService : ICumminsService
    {
        private readonly IWebClientWrapper _client;
        private readonly string _cumminsApiEndpoint = ConfigurationManager.AppSettings["CumminsApiEndpoint"];

        public CumminsService(IWebClientWrapper client)
        {
            _client = client;
        }

        private static int MaxLineItems => int.Parse(ConfigurationManager.AppSettings["CumminsMaxLineItems"]);

        public void SubmitOrder(ref DiaOrder diaOrder)
        {
            for (var i = 0; i < diaOrder.LineItems.Count; i += MaxLineItems)
            {
                var poSuffix = 0;

                var cumminsPoNumber = $"{diaOrder.PoNumber}-{++poSuffix}";
                var lineItemBatch = diaOrder.LineItems.Take(MaxLineItems).Skip(i).ToList();

                var request = BuildApiRequest(diaOrder, lineItemBatch, cumminsPoNumber);
                var jsonRequest = new JavaScriptSerializer().Serialize(request);

                var success = _client.Post(_cumminsApiEndpoint, jsonRequest);

                foreach (var lineItem in lineItemBatch)
                {
                    if (success)
                    {
                        lineItem.CumminsPoNumber = cumminsPoNumber;
                        lineItem.SubmitDate = DateTime.Now;
                    }
                    else
                    {
                        if (lineItem.Retries.HasValue)
                        {
                            lineItem.LastRetryDate = DateTime.Now;
                            lineItem.Retries += 1;
                        }
                        else
                        {
                            lineItem.Retries = 0;
                        }
                    }
                }
            }
        }

        public object BuildApiRequest(DiaOrder order, IList<DiaOrderLineItem> lineItemBatch, string cumminsPoNumber)
        {
            return new
            {
                Header = new
                {
                    Sender = new
                    {
                        MessageID = "123",
                        ServiceName = "DealerComm",
                        SenderID = "SF"
                    },
                    Target = new
                    {
                        TargetID = string.Empty // TODO: This needs to be DistributorCode, waiting for answer on this
                    }
                },
                DataArea = new
                {
                    DealerCode = order.DealerCode,
                    DistributorCode = string.Empty, // TODO: This needs to be DistributorCode, waiting for answer on this
                    RegionCode = string.Empty, 
                    OrderHeader = new
                    {
                        OrderId = string.Empty,
                        IntegrationId = string.Empty, // TODO: Open question about where this comes from: firstOrder.IntegrationId?
                        OrderStatus = "Submitted",
                        OrderType = order.OrderType,
                        DealerCode = order.DealerCode,
                        OrderTotal = lineItemBatch.Sum(o => o.UnitNetPrice),
                        TotalLines = lineItemBatch.Count,
                        CreationDate = DateTime.Now.ToString("yyyy-MM-dd HH':'mm':'ss"),
                        Currency = GetCurrency(order.CountryCode),
                        DeliveryMethod = string.Empty,
                        ContactPhone = string.Empty,
                        ContactName = string.Empty,
                        Attribute1 = "0",
                        ShipVia = order.ShipVia,
                        ShipToName = order.ShipToName,
                        PONumber = cumminsPoNumber,
                        FutureDate = string.Empty,
                        UserComments = string.Empty, // TODO: Open question about whether this needs to be passed
                        CompanyId = string.Empty,
                        DivisionId = string.Empty,
                        DistributorCode = string.Empty, // TODO: This needs to be DistributorCode, waiting for answer on this
                        Locale = "en_US",
                        PCID = "22",
                        BranchName = string.Empty,
                        ConfirmationNumber = string.Empty,
                        RSControlNumber = string.Empty,
                        EngineSerialNumber = string.Empty,
                        PaymentType = string.Empty,
                        SuggestionId = string.Empty,
                        PickUp = string.Empty,  // TODO: Outstanding question about whether this needs to be set or not
                        OnHold = string.Empty,
                        AllocationDisplay = string.Empty,
                        RDCPONumber = string.Empty,
                        POAcknowlegementDate = string.Empty,
                        CorporateBranchNumber = string.Empty,
                        ShippingAddress = new 
                        {
                            LineOne = string.Empty,
                            AddressId = string.Empty,
                            LineTwo = string.Empty,
                            CityName = string.Empty,
                            PostalCode = string.Empty,
                            StateName = string.Empty,
                            CountryCode = string.Empty
                        }
                    },
                    OrderLine = new
                    {
                        PartNumbers = new
                        {
                            Part = GetParts(lineItemBatch)
                        }
                    }
                }
            };
        }

        private static string GetCurrency(string countryCode)
        {
            return countryCode == "CA" ? "CAD" : "USD";
        }

        private static List<object> GetParts(IEnumerable<DiaOrderLineItem> lineItems)
        {
            var parts = new List<object>();

            foreach (var lineItem in lineItems)
            {
                parts.Add(new
                {
                    PartNumber = lineItem.PartNumber,
                    LineId = string.Empty,
                    LineNo = string.Empty,
                    PartDescription = string.Empty,
                    PartQuantity = lineItem.Quantity,
                    UnitNetPrice = lineItem.UnitNetPrice,
                    TotalPrice = lineItem.Quantity * lineItem.UnitNetPrice,
                    ItemNumber = string.Empty,
                    ProductCode = string.Empty,
                    NonEnterprise = string.Empty,
                    Attribute1 = string.Empty,
                    Attribute2 = string.Empty
                });
            }

            return parts;
        }
    }
}
