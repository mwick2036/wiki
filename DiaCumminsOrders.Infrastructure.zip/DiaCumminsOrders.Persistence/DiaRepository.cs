﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiaCumminsOrders.Application.Interfaces;
using DiaCumminsOrders.Domain;

namespace DiaCumminsOrders.Persistence
{
    public class DiaRepository: DbContext, IDiaRepository
    {
        public IDbSet<DiaOrder> DiaOrders { get; set; }
        public void Save()
        {
            this.SaveChanges();
        }

        public DiaRepository() : base("Navistar")
        {
            Database.SetInitializer<DiaRepository>(null);
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Configurations.Add(new DiaOrderConfiguration());
        }
    }
}
