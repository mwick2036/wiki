﻿using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiaCumminsOrders.Domain;

namespace DiaCumminsOrders.Persistence
{
    public class DiaOrderConfiguration : EntityTypeConfiguration<DiaOrder>
    {
        public DiaOrderConfiguration()
        {
            HasKey(o => o.Id);

            HasMany(o => o.LineItems).WithRequired(o => o.DiaOrder);
        }
    }
}
