﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using DiaCumminsOrders.Application.Interfaces;
using DiaCumminsOrders.Domain;

namespace DiaCumminsOrders.Application.Commands.SubmitOrders
{
    public class SubmitOrdersCommand : ISubmitOrdersCommand
    {
        private readonly IDiaRepository _diaRepository;
        private readonly ICumminsService _cumminsService;

        public bool ProcessRunning { get; set; }

        public SubmitOrdersCommand(IDiaRepository diaRepository, ICumminsService cumminsService)
        {
            _diaRepository = diaRepository;
            _cumminsService = cumminsService;

            ProcessRunning = false;
        }

        public void Execute(int? serviceKey)
        {
            if (ProcessRunning)
                return;

            ProcessRunning = true;

            try
            {
                Expression<Func<DiaOrder, bool>> where;

                if (serviceKey.HasValue)
                    where = order => order.ServiceKey == serviceKey;
                else
                    where = order => order.LineItems.Count(l => l.SubmitDate == null && l.Retries != null) > 0;

                var diaOrders = _diaRepository.DiaOrders.Where(where).ToArray();

                for (var i = 0; i < diaOrders.Length; i++)
                {
                    _cumminsService.SubmitOrder(ref diaOrders[i]);
                }

                _diaRepository.Save();
            }
            finally
            {
                ProcessRunning = false;
            }
        }
    }
}
