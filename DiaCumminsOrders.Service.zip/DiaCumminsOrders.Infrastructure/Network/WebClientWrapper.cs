﻿using System;
using System.Net;
using System.Web.Configuration;
using System.Web.Helpers;
using System.Web.Script.Serialization;
using DiaCumminsOrders.Infrastructure.Helpers;

namespace DiaCumminsOrders.Infrastructure.Network
{
    public class WebClientWrapper : IWebClientWrapper
    {
        public bool Post(string address, string json)
        {
            try
            {
                using (var client = new TimeoutWebClient())
                {
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";

                    var response = client.UploadString(address, "POST", json);
                    var responseData = Json.Decode(response);

                    if (responseData.Header != null && responseData.Header.Status.ToLower() == "success")
                        return true;
                }
            }
            catch (Exception ex)
            {
                // TODO: Log exception
            }

            return false;
        }
    }
}
