﻿using System;
using System.Configuration;
using System.Net;

namespace DiaCumminsOrders.Infrastructure.Helpers
{
    public class TimeoutWebClient : WebClient
    {
        private static int TimeoutThreshold => int.Parse(ConfigurationManager.AppSettings["CumminsApiTimeoutThreshold"]);

        protected override WebRequest GetWebRequest(Uri address)
        {
            var request = (HttpWebRequest)base.GetWebRequest(address);

            if (request != null)
                request.Timeout = TimeoutThreshold;

            return request;
        }
    }
}
