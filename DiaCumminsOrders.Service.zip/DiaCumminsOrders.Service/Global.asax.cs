﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using DiaCumminsOrders.Application.Commands.SubmitOrders;

namespace DiaCumminsOrders.Service
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        //private ISubmitOrdersCommand _submitOrdersCommand;
        //private CancellationTokenSource _token;

        protected void Application_Start()
        {
            //_submitOrdersCommand = submitOrdersCommand;

            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            //_token = new CancellationTokenSource();
            //var interval = new TimeSpan(0, 10, 0);


        }
    }
}
