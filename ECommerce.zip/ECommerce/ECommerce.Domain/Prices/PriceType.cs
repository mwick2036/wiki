﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Domain.Prices
{
    [Table("DHTP930_PRCE_TYP_CD")]
    public class PriceType
    {
        [Key]
        [Column("PRCE_CD")]
        public string Id { get; set; }

        [Column("PRCE_SYS_FLD_NAME")]
        public string SystemFieldName { get; set; }
    }
}
