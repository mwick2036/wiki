﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECommerce.Domain.Dealers;

namespace ECommerce.Domain.Customers
{
    [Table("DHTP160_CUST_LOC")]
    public class CustomerLocation
    {
        [Key]
        [ForeignKey("Customer")]
        [Column("CUST_NME", Order = 0)]
        public string CustomerName { get; set; }

        [Key]
        [Column("CUST_LOC_CD", Order = 1)]
        public string CustomerLocationCode { get; set; }

        [Column("CUST_ZIP_PSTL_CD")]
        public string ShipToPostalCode { get; set; }

        [Column("AOR_I")]
        public string IsAor { get; set; }

        [ForeignKey("Dealer")]
        [Column("PO_PART_PRVDR_ID")]
        public int DealerId { get; set; }

        [Column("PART_CUST_LOC_NO")]
        public string PartCustomerLocationCode { get; set; }

        [Column("ERR_NOTIF_ADDR")]
        public string ErrorNotifyEmailAddress { get; set; }

        [Column("SPA_FLT_ID")]
        public string SpaFleetId { get; set; }

        [Column("ORD_RTE")]
        public string OrderRoute { get; set; }

        [Column("CREAT_TS")]
        public DateTime CreateDate { get; set; }

        [Column("CREAT_UID")]
        public string CreateUserId { get; set; }

        [Column("LST_CHNG_TS")]
        public DateTime LastChangeDate { get; set; }

        [Column("LST_CHNG_UID")]
        public string LastChangeUserId { get; set; }

        public virtual Customer Customer { get; set; }
        public virtual Dealer Dealer { get; set; }
    }
}
