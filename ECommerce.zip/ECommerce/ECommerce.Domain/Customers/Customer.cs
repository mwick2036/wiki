﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECommerce.Domain.Dealers;
using ECommerce.Domain.Prices;

namespace ECommerce.Domain.Customers
{
    [Table("DHTP150_CUST_MSTR")]
    public class Customer
    {
        [Column("PO_CUST_NME")]
        public string OrderCustomerName { get; set; }

        [Column("XML_IDNTY_ID")]
        public string IdentityId { get; set; }

        [Key]
        [Column("CUST_NME")]
        public string CustomerName { get; set; }

        [Column("ERR_NOTIF_ADDR")]
        public string ErrorNotifyEmailAddress { get; set; }

        [Column("PART_CUST_NO")]
        public string PartCustomerNumber{ get; set; }

        [Column("CREAT_TS")]
        public DateTime CreateDate { get; set; }

        [Column("CREAT_UID")]
        public string CreateUserId { get; set; }

        [Column("LST_CHNG_TS")]
        public DateTime LastChangeDate { get; set; }

        [Column("LST_CHNG_UID")]
        public string LastChangeUserId { get; set; }

        [ForeignKey("Dealer")]
        [Column("DFALT_PART_PRVDR_ID")]
        public int? DefaultDealerId { get; set; }

        [Column("CNTCT_NME")]
        public string ContactName { get; set; }

        [Column("CUST_CNTCT_EMAIL")]
        public string ContactEmailAddress { get; set; }

        [Column("CUST_CNTCT_PHONE_NO")]
        public string ContactPhone { get; set; }

        [Column("SUBM_ORD_IND")]
        public string IsOrderSubmitted { get; set; }

        [ForeignKey("PriceType")]
        [Column("DEF_PRCE_TYP")]
        public string DefaultPriceType { get; set; }

        [Column("DEF_ORD_RTE")]
        public string DefaultOrderRoute { get; set; }

        [Column("PRCE_MARKUP_VALUE")]
        public decimal MarkupValue { get; set; }

        [Column("APPLY_SPA_DISCOUNTS")]
        public string ApplySpaDiscounts { get; set; }

        [Column("FLEET_CATLG_ACCESS_IND")]
        public string HasFleetCatalogAccess { get; set; }

        [Column("B_TO_B_ORDERS_IND")]
        public string HasBtoBOrders { get; set; }

        [Column("CUST_PO_NO_PREFIX")]
        public string OrderNumberPrefix { get; set; }

        [Column("USE_DS_DCN_PRGMS")]
        public string UseDsDcnPrgrms { get; set; }

        [Column("BUS_ONLY_CUST_IND")]
        public string IsBusOnly { get; set; }

        [Column("ISIS_SUBSCRIPTION_IND")]
        public string HasISISSubscription { get; set; }

        [Column("INC_CORE_IN_PRCE_IND")]
        public string HasIncCoreInPrice { get; set; }

        [Column("CORE_MARKUP_VALUE")]
        public decimal CoreMarkupValue { get; set; }

        [Column("APPLY_SPA_DISCOUNT_TO_CORE")]
        public string ApplySpaDiscountToCore { get; set; }

        public virtual PriceType PriceType { get; set; }
        public virtual Dealer Dealer { get; set; }
        public virtual ICollection<CustomerLocation> CustomerLocations { get; set; }
    }
}
