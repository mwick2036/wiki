﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECommerce.Domain.Dealers;

namespace ECommerce.Domain.Customers
{
    // TODO: Consider combining this with CustomerLocation.cs if it makes sense
    [Table("CWTP030_CUST_LOC")]
    public class ExternalCustomerLocation
    {
        [Column("PART_CUST_LOC_NO")]
        public string CustomerLocationNumber { get; set; }

        [Column("SHIP_NME")]
        public string ShipToName { get; set; }

        [Column("SHIP_ADDR")]
        public string ShipToAddress { get; set; }

        [Column("SHIP_ADDR_2")]
        public string ShipToAddressLine2 { get; set; }

        [Column("SHIP_CITY")]
        public string ShipToCity { get; set; }

        [Column("SHIP_ST_PROV_CD")]
        public string ShipToState { get; set; }

        [Column("SHIP_ZIP_PSTL_CD")]
        public string ShipToPostalCode { get; set; }

        [Column("ST_PROV_CTRY")]
        public string ShipToCountry { get; set; }

        [Column("FLT_CHRG_NO")]
        public string FleetChargeNumber { get; set; }

        [Column("PRFL_LOC_STAT_CD")]
        public string ProfileLocationStatusCode { get; set; }

        [Column("PART_CUST_ACCT_NO")]
        public string CustomerAccountNumber { get; set; }
    }
}
