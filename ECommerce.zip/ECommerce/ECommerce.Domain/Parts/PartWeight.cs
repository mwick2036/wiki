﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Domain.Parts
{
    [Table("PETP050_PART_MSTR")]
    public class Part
    {
        [Key]
        [ForeignKey("PartCountry")]
        [Column("PART_25_NO")]
        public string PartNumber { get; set; }

        [Column("PART_SHORT_DESC")]
        public string ShortDescription { get; set; }

        public virtual PartCountry PartCountry { get; set; }
    }
}
