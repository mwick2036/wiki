﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Domain.Parts
{
    [Table("PQTP140_WGHT_MEAS")]
    public class PartWeight
    {
        [Column("PART_25_NO")]
        public string PartNumber { get; set; }

        [Column("PART_UNT_WGHT")]
        public string PartUnitWeight { get; set; }
    }
}
