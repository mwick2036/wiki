﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Domain.Parts
{
    [Table("XRTP070_PRT_DOMAIN")]
    public class PartDomain
    {
        [Key]
        [Column("PART_25_NO")]
        public string PartNumber { get; set; }

        [Column("PART_NO_OWNR_ID")]
        public string PartOwner { get; set; }

        [Column("TEXT_30_DESC")]
        public string PartDescription { get; set; }
    }
}
