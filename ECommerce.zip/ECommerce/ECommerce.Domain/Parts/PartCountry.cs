﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Domain.Parts
{
    [Table("PETP020_CTRY_PART")]
    public class PartCountry
    {
        [Key]
        [Column("PART_25_NO")]
        public string PartNumber { get; set; }

        [Column("ST_PROV_CTRY")]
        public string CountryCode { get; set; }

        [Column("PART_ITM_CD")]
        public string PartItemCode { get; set; }

        [Column("DS_PART_ITM_CD")]
        public string DsPartItemCode { get; set; }

        [Column("PART_MRKT_METH_ID")]
        public string PartMarketMethodId { get; set; }

        [Column("HRMNZ_HDR_CD")]
        public string HarmonizeHeaderCode { get; set; }

        [Column("HRMNZ_SUB_HDR_CD")]
        public string HarmonizeSubHeaderCode { get; set; }

        [Column("PART_TARIFF_CD")]
        public string PartTariffCode { get; set; }

        [Column("HRMNZ_STAT_REFR_Cd")]
        public string HarmonizeStatReferralCode { get; set; }
    }
}
