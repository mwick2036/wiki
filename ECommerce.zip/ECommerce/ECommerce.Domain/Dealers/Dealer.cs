﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECommerce.Domain.Requests;

namespace ECommerce.Domain.Dealers
{
    [Table("DHTP170_PART_PRVDR")]
    public class Dealer
    {
        [Key]
        [Column("PO_PART_PRVDR_ID")]
        public int Id { get; set; }

        [Column("DOC_TARGT_ADDR")]
        public string TargetEmailAddress { get; set; }

        [Column("PRVDR_LOC_NO")]
        public string DealerCode { get; set; }

        [Column("GENL_PHONE_NO")]
        public string PhoneNumber { get; set; }

        [Column("CNTCT_NME")]
        public string ContactName { get; set; }

        [ForeignKey("RequestTransmitMethod")]
        [Column("XMT_METH_CD")]
        public string RequestTransmitMethodCode { get; set; }

        [ForeignKey("RequestDocumentType")]
        [Column("PO_DOC_TYP_CD")]
        public string RequestDocumentTypeId { get; set; }

        [Column("XTRNL_PRVDR_I")]
        public string IsExternalDealer { get; set; }

        [Column("CREAT_TS")]
        public DateTime CreateDate { get; set; }

        [Column("CREAT_UID")]
        public string CreateUserId { get; set; }

        [Column("LST_CHNG_TS")]
        public DateTime LastChangeDate { get; set; }

        [Column("LST_CHNG_UID")]
        public string LastChangeUserId { get; set; }

        public virtual RequestTransmitMethod RequestTransmitMethod { get; set; }
        public virtual RequestDocumentType RequestDocumentType { get; set; }
    }
}
