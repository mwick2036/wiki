﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Domain.Requests
{
    [Table("DHTP945_XML_REQ_TYPE")]
    public class RequestType
    {
        [Key]
        [Column("REQ_TYPE_CD")]
        public string RequestTypeCode { get; set; }

        [Column("XML_NODE_NME")]
        public string XmlNodeName { get; set; }

        [Column("VIEW_STYL_LANG_SHT")]
        public string XmlStylesheet { get; set; }
    }
}
