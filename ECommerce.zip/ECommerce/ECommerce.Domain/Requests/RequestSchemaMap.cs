﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Domain.Requests
{
    [Table("DHTP110_XML_DOC")]
    public class RequestSchemaMap
    {
        [Key]
        [Column("DOC_NME")]
        public string DocumentName { get; set; }

        [Column("XML_STYL_LANG_SHT")]
        public string SchemaFileName { get; set; }

        [Column("TRNSFM_REQ_IND")]
        public string TransformRequired { get; set; }
    }
}
