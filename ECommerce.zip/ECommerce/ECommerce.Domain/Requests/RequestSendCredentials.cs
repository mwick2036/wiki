﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Domain.Requests
{
    [Table("DHTP120_DOC_SEND_CREDENTIALS")]
    public class RequestSendCredentials
    {
        [Key]
        [Column("DOC_SEND_ID")]
        public int Id { get; set; }

        [Column("DOMN_ID")]
        public string DomainId { get; set; }

        [Column("IDNTY_DATA")]
        public string IdentityData { get; set; }

        [Column("PSWD_DATA")]
        public string PasswordData { get; set; }
    }
}
