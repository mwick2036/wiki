﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Domain.Requests
{
    [Table("DHTP900_XMT_METH")]
    public class RequestTransmitMethod
    {
        [Key]
        [Column("XMT_METH_CD")]
        public string TransmitMethodCode { get; set; }

        [Column("CD_DESC")]
        public string Description { get; set; }

        [Column("XMT_TYP_CD")]
        public string TransmitType { get; set; }
    }
}
