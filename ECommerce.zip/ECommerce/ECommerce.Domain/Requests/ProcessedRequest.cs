﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECommerce.Domain.Orders;

namespace ECommerce.Domain.Requests
{
    [Table("DHTP975_PRCS_QUEUE")]
    public class ProcessedQueue
    {
        [Key]
        [ForeignKey("ProcessedRequest")]
        [Column("DOC_ID")]
        public int Id { get; set; }

        [Column("LST_PRCS_TS")]
        public DateTime LastProcessedDate { get; set; }

        [Column("CREAT_TS")]
        public DateTime CreateDate { get; set; }

        public virtual ProcessedRequest ProcessedRequest { get; set; }
    }

    [Table("DHTP820_DOC_DATA")]
    public class ProcessedRequest
    {
        [Key]
        [Column("DOC_ID")]
        public int Id { get; set; }

        [ForeignKey("Order")]
        [Column("PO_NO")]
        public int? OrderId { get; set; }

        [Column("CREAT_TS")]
        public DateTime CreateDate { get; set; }

        [Column("DOC_DATA")]
        public string Contents { get; set; }

        //[ForeignKey("RequestType")]
        [Column("REQ_TYPE_CD")]
        public string RequestTypeCode { get; set; }

        [Column("VIEW_STYL_LANG_SHT")]
        public string Schema { get; set; }

        [Column("PAYLOAD_ID")]
        public string PayloadId { get; set; }

        [Column("RCPT_NO")]
        public int ReceiptNumber { get; set; }

        [Column("REQ_ST_CD")]
        public string RequestStatusCode { get; set; }

        [Column("REQ_ACTN_CD")]
        public string RequestActionCode { get; set; }

        public virtual Order Order { get; set; }
    }
}
