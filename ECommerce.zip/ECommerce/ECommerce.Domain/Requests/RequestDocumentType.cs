﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Domain.Requests
{
    [Table("DHTP940_PO_DOC_TYP")]
    public class RequestDocumentType
    {
        [Key]
        [Column("PO_DOC_TYP_CD")]
        public string Id { get; set; }

        [ForeignKey("RequestType")]
        [Column("REQ_TYPE_CD")]
        public string RequestTypeCode { get; set; }

        public virtual RequestType RequestType { get; set; }
    }
}
