﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Domain.Requests
{
    [Table("DHTP971_RCPT_QUEUE")]
    public class ReceiptQueue
    {
        [Key]
        [ForeignKey("ReceivedRequest")]
        [Column("RCPT_NO")]
        public int Id { get; set; }

        [Column("LST_PRCS_TS")]
        public DateTime LastProcessedDate { get; set; }

        [Column("CREAT_TS")]
        public DateTime CreateDate { get; set; }

        public virtual ReceivedRequest ReceivedRequest { get; set; }
    }

    [Table("DHTP970_DOC_RCPT")]
    public class ReceivedRequest
    {
        [Key]
        [Column("RCPT_NO")]
        public int Id { get; set; }

        [Column("PROC_DOC_DATA")]
        public string Contents { get; set; }

        [Column("SRCE_PGM_ID")]
        public string SourceProgramId { get; set; }

        [Column("CREAT_TS")]
        public DateTime CreateDate { get; set; }
    }
}
