﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using ECommerce.Domain.Customers;
using ECommerce.Domain.Dealers;

namespace ECommerce.Domain.Orders
{
    [Table("DHTP966_PO_DTL")]
    public class OrderLineItem
    {
        [Key]
        [ForeignKey("Order")]
        [Column("PO_NO", Order = 0)]
        public int OrderId { get; set; }

        [Key]
        [Column("PO_LNE_NO", Order = 1)]
        public string OrderLineNumber { get; set; }

        [Column("CREAT_TS")]
        public DateTime CreateDate { get; set; }

        [Column("ORD_QTY")]
        public int Quantity { get; set; }

        [Column("PART_25_NO")]
        public string PartNumber { get; set; }

        [Column("UNIT_PRC")]
        public decimal UnitPrice { get; set; }

        [Column("PART_DESC")]
        public string PartDescription { get; set; }

        [Column("PART_CMDTY_GRP_CD")]
        public string PartCommodityGroupCode { get; set; }

        [Column("PART_BKORD_QTY")]
        public int BackorderQuantity { get; set; }

        [Column("EST_SHIP_REMN_DTE")]
        public DateTime EstShipRemainDate { get; set; }

        [Column("STAT_CD")]
        public string Status { get; set; }

        [Column("PART_SUPLD_QTY")]
        public int SuppliedQuantity { get; set; }

        [Column("PART_NAT_FLT_PRCE")]
        public decimal NatlFleetPrice { get; set; }

        [Column("ORD_ITM_RTE")]
        public string Route { get; set; }

        [Column("PART_UNT_WGHT")]
        public decimal PartUnitWeight { get; set; }

        public virtual Order Order { get; set; }
    }

    [Table("DHTP965_PO_HDR")]
    public class Order
    {
        [Key]
        [Column("PO_NO")]
        public int Id { get; set; }

        [ForeignKey("CustomerLocation")]
        [Column("CUST_NME", Order = 0)]
        public string CustomerName { get; set; }

        [ForeignKey("CustomerLocation")]
        [Column("CUST_LOC_CD", Order = 1)]
        public string CustomerLocationCode { get; set; }

        [Column("CUST_PO_NO")]
        public string CustomerOrderNumber { get; set; }

        [Column("STAT_CD")]
        public string Status { get; set; }

        [Column("CREAT_TS")]
        public DateTime CreateDate { get; set; }

        [ForeignKey("Dealer")]
        [Column("PO_PART_PRVDR_ID")]
        public int DealerId { get; set; }

        [Column("ORD_TYP_CD")]
        public string OrderType { get; set; }

        [Column("CLOSE_TS")]
        public DateTime? CloseDate { get; set; }

        [Column("CLOSE_UID")]
        public string CloseUserId { get; set; }

        [Column("ORD_RTE")]
        public string OrderRouting { get; set; }

        public virtual CustomerLocation CustomerLocation { get; set; }
        public virtual Dealer Dealer { get; set; }
        public virtual ICollection<OrderLineItem> OrderLineItems { get; set; }
    }
}
