﻿using System;
using System.Collections.Generic;
using ECommerce.Application.Interfaces;
using ECommerce.Application.Requests.Commands.CompleteProcessedRequests;
using ECommerce.Application.Requests.Commands.ProcessReceivedRequests;
using ECommerce.Application.Requests.Commands.ReceivePostedRequests;
using ECommerce.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ECommerce.Service.Tests
{
    [TestClass]
    public class ExternalRepositoryTests
    {
        [TestMethod]
        public void GetPartCountryWithValidPartNumberAndCountry_ReturnsValidResult()
        {
            IExternalRepository externalRepository = new ExternalRepository();

            const string partNumber = "00002-1/4L";
            var countryCodes = new List<string> {"CAN"};

            var partCountry = externalRepository.GetPartCountry(partNumber, countryCodes);

            Assert.IsNotNull(partCountry);
            Assert.AreEqual(partCountry.PartItemCode, "00331");
        }

        [TestMethod]
        public void GetPartDomainWithValidPartNumberAndPartOwner_ReturnsValidResult()
        {
            IExternalRepository externalRepository = new ExternalRepository();

            const string partNumber = "34004313";
            const string partOwner = "CRST";

            var partDomain = externalRepository.GetPartDomain(partNumber, partOwner);

            Assert.IsNotNull(partDomain);
            Assert.AreEqual(partDomain.PartNumber, partNumber);
            Assert.AreEqual(partDomain.PartOwner, partOwner);
            Assert.AreEqual(partDomain.PartDescription, "RING");
        }

        [TestMethod]
        public void GetExternalLocationWithValidLocationId_ReturnsValidResult()
        {
            IExternalRepository externalRepository = new ExternalRepository();

            const string locationId = "RTL00833";

            var location = externalRepository.GetExternalCustomerLocation(locationId);

            Assert.IsNotNull(location);
            Assert.AreEqual(location.CustomerLocationNumber, locationId);
            Assert.AreEqual(location.CustomerAccountNumber, "000109");
            Assert.AreEqual(location.ShipToName, "DEVILS LAKE MUNICIPAL");
            Assert.AreEqual(location.ShipToAddress, "AIRPORT AUTHORITY");
            Assert.AreEqual(location.ShipToAddressLine2, "106 NATL GUARD ST NW");
            Assert.AreEqual(location.ShipToCity, "DEVILS LAKE");
            Assert.AreEqual(location.ShipToState, "ND");
            Assert.AreEqual(location.ShipToPostalCode, "58301");
            Assert.AreEqual(location.ShipToCountry, "USA");
        }
    }
}
