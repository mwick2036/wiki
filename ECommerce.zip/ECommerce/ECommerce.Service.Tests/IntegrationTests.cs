﻿using System;
using ECommerce.Application.Interfaces;
using ECommerce.Application.Requests.Commands.CompleteProcessedRequests;
using ECommerce.Application.Requests.Commands.ProcessReceivedRequests;
using ECommerce.Application.Requests.Commands.ReceivePostedRequests;
using ECommerce.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ECommerce.Service.Tests
{
    [TestClass]
    public class IntegrationTests
    {
        [TestMethod]
        public void ReceivePostsIntegrationTest()
        {
            IECommerceRepository repo = new ECommerceRepository();

            var sut = new ReceiveCommand(repo);

            sut.Execute();
        }

        [TestMethod]
        public void ProcessReceiptsIntegrationTest()
        {
            IECommerceRepository repo = new ECommerceRepository();

            var sut = new ProcessCommand(repo);

            sut.Execute();
        }

        [TestMethod]
        public void CompleteProcessedIntegrationTest()
        {
            IECommerceRepository eCommerceRepository = new ECommerceRepository();
            IExternalRepository externalRepository = new ExternalRepository();

            var sut = new CompleteCommand(eCommerceRepository, externalRepository);

            sut.Execute();
        }
    }
}
