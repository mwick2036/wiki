﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Xsl;
using System.IO;
using System.Xml.Schema;
using ECommerce.Application.Interfaces;
using ECommerce.Application.Requests.Commands.ReceivePostedRequests.Translators;
using ECommerce.Domain.Requests;

namespace ECommerce.Application.Requests.Commands.ProcessReceivedRequests
{
    public class ProcessCommand : IProcessCommand
    {
        private readonly IECommerceRepository _eCommerceRepository;

        public ProcessCommand(IECommerceRepository eCommerceRepository)
        {
            _eCommerceRepository = eCommerceRepository;
        }

        public void Execute()
        {
            var receiptQueue = _eCommerceRepository.ReceiptQueue.ToList();

            try
            {
                foreach (var receivedItem in receiptQueue)
                {
                    ProcessReceivedRequest(receivedItem);
                    // TODO: Need to remove item from queue
                }

                _eCommerceRepository.Save();
            }
            catch (Exception ex)
            {
                // TODO: Log exception
                throw ex;
            }
        }

        private void ProcessReceivedRequest(ReceiptQueue receivedItem)
        {
            var docName = string.Empty;
            var document = TransformReceipt(receivedItem, out docName);

            if (document.DocumentType != null && document.DocumentType.Name.ToUpper() != "CXML")
            {
                // TODO: Log exception (see clsRecdXMLDocument.vb lines 60-63)
                throw new Exception();
            }

            if (!IsValid(document))
            {
                // TODO: Log exception (see clsDocSender.vb lines 19-20)
                throw new Exception();
            }

            if (IsDuplicate(document))
            {
                // TODO: Log exception (see clsDocSender.vb lines 19-20)
                throw new Exception();
            }

            // TODO: See about replacing this with object with XML attributes (see XmlOrder for example)
            var baseRoot = document.SelectSingleNode("//cXML");

            if (baseRoot == null)
            {
                // TODO: Use same pattern established from other exception handling in this method
                throw new Exception();
            }

            var basePayloadId = baseRoot.Attributes["payloadID"].Value;

            var requestRoot = document.SelectSingleNode("//cXML/Request");

            if (requestRoot != null)
            {
                var iOrderSequence = 0;

                foreach (XmlNode request in requestRoot.ChildNodes)
                {
                    var reqType = _eCommerceRepository.RequestTypes.FirstOrDefault(r => r.XmlNodeName == request.Name);
                    if (reqType != null)
                    {
                        if (requestRoot.ChildNodes.Count > 1)
                        {
                            // TODO: See clsRecdXMLDocument.vb lines 95-97 on how to handle this
                        }

                        var extrinsicCustId = string.Empty;
                        var extrinsicCustNode = request.ChildNodes[0].SelectSingleNode("Extrinsic[@name='customerId']");

                        if (extrinsicCustNode != null)
                        {
                            extrinsicCustId = extrinsicCustNode.Value;
                        }

                        if (!string.IsNullOrEmpty(extrinsicCustId))
                        {
                            var identityNode = document.SelectSingleNode("//cXML/Header/From/Credential");
                            if (identityNode != null)
                            {
                                identityNode.SelectSingleNode("Identity").Value = extrinsicCustId;
                            }
                        }

                        if (iOrderSequence == 0 && document.DocumentType != null && document.DocumentType.Name != "CXML")
                        {
                            // TODO: Look into XML Document validate method (see clsRecdXMLDocument.vb lines 114-119)
                            //var valid = document.Validate();
                        }

                        iOrderSequence++;

                        var payloadId = string.Empty;

                        if (baseRoot.Attributes != null)
                        {
                            payloadId = $"{basePayloadId}-{iOrderSequence}";
                            baseRoot.Attributes["payloadID"].Value = payloadId;
                        }

                        _eCommerceRepository.ProcessedRequests.Add(new ProcessedRequest()
                        {
                            RequestTypeCode = reqType.RequestTypeCode,
                            PayloadId = payloadId,
                            ReceiptNumber = receivedItem.ReceivedRequest.Id,
                            Contents = document.InnerXml,
                            Schema = _eCommerceRepository.RequestTypes.FirstOrDefault(r => r.RequestTypeCode == reqType.RequestTypeCode)?.XmlStylesheet,
                            CreateDate = DateTime.Now,
                            RequestActionCode = "N",        // TODO: Verify this is correct initial setting
                            RequestStatusCode = "N"         // TODO: Verify this is correct initial setting
                        });
                    }
                }
            }
        }

        private XmlDocument TransformReceipt(ReceiptQueue receivedItem, out string docName)
        {
            var transformed = new XmlDocument();

            var cnfLocations = (NameValueCollection)ConfigurationManager.GetSection("FleetService/Locations");
            var templateLocation = cnfLocations["XLSTemplates"];

            // TODO: All this directory-changing business needs to be moved if it fixes XSLT compile error
            var curDir = Directory.GetCurrentDirectory();

            var templateDirectory = new DirectoryInfo(templateLocation);

            Directory.SetCurrentDirectory(templateDirectory.FullName);

            var inXmlDocument = new XmlDocument();
            inXmlDocument.LoadXml(receivedItem.ReceivedRequest.Contents);

            docName = string.Empty;

            if (inXmlDocument.DocumentElement != null)
            {
                docName = inXmlDocument.DocumentType?.Name ?? inXmlDocument.DocumentElement.Name;
            }

            var name = docName;
            var schemaMap = _eCommerceRepository.RequestSchemaMaps.FirstOrDefault(x => x.DocumentName == name); // .SchemaTemplates.Where(x => x.Key == docType);
            if (schemaMap == null)
                throw new Exception($"Schema map not found for doc name = {docName}");

            if (schemaMap.TransformRequired == "Y")
            {
                var stylesheet = new XmlDocument();
                stylesheet.Load(templateLocation + "\\" + schemaMap.SchemaFileName);

                transformed.LoadXml(TransformDocument(inXmlDocument, stylesheet));
            }

            Directory.SetCurrentDirectory(curDir);

            return transformed;
        }

        private string TransformDocument(XmlDocument doc, XmlDocument stylesheet)
        {
            var xmlResolver = new XmlUrlResolver();
            var transform = new XslCompiledTransform();

            var settings = new XsltSettings
            {
                EnableDocumentFunction = true,
                EnableScript = true
            };

            transform.Load(stylesheet, settings, xmlResolver); // compiled stylesheet

            var writer = new System.IO.StringWriter();
            transform.Transform(doc, null, writer);
            return writer.ToString();
        }

        private bool IsValid(XmlDocument document)
        {
            var senderRoot = document.SelectSingleNode("//cXML/Header/Sender");

            if (senderRoot != null)
            {
                foreach (XmlNode credential in senderRoot.ChildNodes)
                {
                    var domain = credential.Attributes?["domain"].Value;
                    var identity = credential.SelectSingleNode("Identity")?.InnerText;

                    if (credential.Name == "Credential")
                    {
                        if (credential.Attributes != null && domain == "cust_no")
                        {
                            var dealerCode = identity;

                            if (string.IsNullOrEmpty(dealerCode))
                                return false;

                            if (_eCommerceRepository.Dealers.Any(d => d.DealerCode == dealerCode))
                                return true;
                        }
                        else
                        {
                            var sender = _eCommerceRepository.RequestSendCredentials
                                .FirstOrDefault(r => r.IdentityData == identity && r.DomainId == domain);

                            if (sender != null)
                            {
                                var sharedSecret = credential.SelectSingleNode("SharedSecret");

                                if (sharedSecret != null)
                                {
                                    if (sharedSecret.InnerText != sender.PasswordData || sender.PasswordData == null)
                                    {
                                        // TODO: Log exception, see clsDocSender.vb lines 68-70
                                        throw new Exception();
                                    }
                                }

                                return true;
                            }
                        }
                    }
                }
            }
            else
            {
                // TODO: Log exception, see clsDocSender.vb lines 81-83
                throw new Exception();
            }

            return false;
        }

        private bool IsDuplicate(XmlDocument document)
        {
            var cXmlNode = document.SelectSingleNode("//cXML");
            if (cXmlNode?.Attributes == null)
                return false;

            var payloadId = cXmlNode.Attributes["payloadID"].Value;

            return _eCommerceRepository.ProcessedRequests.Any(r => r.PayloadId.StartsWith(payloadId));
        }

        private void LogException(PostedRequest request)
        {
            // TODO: Implement
        }
    }
}
