﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Application.Requests.Commands.ProcessReceivedRequests
{
    public interface IProcessCommand
    {
        void Execute();
    }
}
