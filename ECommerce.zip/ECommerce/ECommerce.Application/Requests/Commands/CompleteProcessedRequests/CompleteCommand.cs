﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using ECommerce.Application.Interfaces;
using ECommerce.Application.Requests.Commands.CompleteProcessedRequests.XmlObjects;
using ECommerce.Application.Requests.Commands.ReceivePostedRequests.Translators;
using ECommerce.Domain.Customers;
using ECommerce.Domain.Dealers;
using ECommerce.Domain.Requests;

namespace ECommerce.Application.Requests.Commands.CompleteProcessedRequests
{
    public class CompleteCommand : ICompleteCommand
    {
        private const string OrderRequestName = "OrderRequest";

        private readonly IECommerceRepository _eCommerceRepository;

        public CompleteCommand(IECommerceRepository eCommerceRepository)
        {
            _eCommerceRepository = eCommerceRepository;
        }

        public void Execute()
        {
            try
            {
                var processedRequests = _eCommerceRepository.ProcessedQueue.ToList();

                foreach (var request in processedRequests)
                {
                    var docType = request.ProcessedRequest.RequestTypeCode.TrimEnd();

                    switch (docType.ToUpper())
                    {
                        case "ORDER":
                            ProcessOrder(request.ProcessedRequest);
                            break;

                        case "CONFIRM":
                            ProcessConfirmation(request.ProcessedRequest);
                            break;

                        case "SHIPNOTICE":
                            ProcessShipmentNotice(request.ProcessedRequest);
                            break;

                        case "INVOICE":
                            ProcessInvoice(request.ProcessedRequest);
                            break;

                        case "POSETUP":
                            ProcessPunchoutSetup(request.ProcessedRequest);
                            break;
                    }
                }

                _eCommerceRepository.Save();
            }
            catch (Exception ex)
            {
                // TODO: See clsPrcsPrcsDocs.vb line 127+ for how to implement.
            }
        }

        #region Order Processing
        private void ProcessOrder(ProcessedRequest request)
        {
            if (request.RequestStatusCode != "N" && request.RequestStatusCode != "P")
            {
                // TODO: See clsOrderRequest.vb lines 138-140 to handle
                throw new Exception();
            }

            if (request.RequestTypeCode.TrimEnd().ToUpper() != "ORDER")
            {
                // TODO: See clsOrderRequest.vb lines 151-154 to handle
                throw new Exception();
            }

            XmlOrder xmlOrder;
            
            var serializer = new XmlSerializer(typeof(XmlOrder));
            using (TextReader reader = new StringReader(request.Contents))
            {
                xmlOrder = (XmlOrder) serializer.Deserialize(reader);
            }

            var isDealerOrder = false;

            var domain = xmlOrder.Header.From.Credential.Domain;

            if (domain != null && domain.ToLower() == "dealer")
                isDealerOrder = true;

            AssignDealerAndLocation(xmlOrder, out var assignedDealer, out var assignedCustLoc);

            var requestHeader = xmlOrder.Request.OrderRequest.OrderRequestHeader;
            var existingOrder = _eCommerceRepository
                .Orders
                .FirstOrDefault(o =>
                    o.CustomerOrderNumber == requestHeader.OrderId &&
                    o.CustomerName == assignedCustLoc.CustomerName);

            if (existingOrder != null)
            {
                // Update
            }
            else
            {
                // Add
                Dealer responsibleDealer;
                var dealerAcctNbr = string.Empty;

                if (isDealerOrder)
                {
                    const int tolasDealerId = 5;

                    responsibleDealer = _eCommerceRepository.Dealers.FirstOrDefault(d => d.Id == tolasDealerId);
                }
                else
                {
                    var headerExts = requestHeader.Extrinsics;

                    var orderRte = headerExts.FirstOrDefault(e => e.Name == "OrderRte")?.Value;
                    var willCall = headerExts.FirstOrDefault(e => e.Value == "Will_Call")?.Value;

                    if ((orderRte == "WC" || orderRte == "DS") && willCall != null)
                    {
                        responsibleDealer = _eCommerceRepository.Dealers.FirstOrDefault(d =>
                            d.DealerCode == willCall && d.RequestDocumentType.RequestType.RequestTypeCode == "ORDER");
                    }
                    else if (assignedDealer.DealerCode.Contains("TOLAS") && !string.IsNullOrEmpty(assignedCustLoc.PartCustomerLocationCode))
                    {
                        responsibleDealer = _eCommerceRepository.Dealers.FirstOrDefault(d =>
                            d.DealerCode == assignedCustLoc.PartCustomerLocationCode && d.RequestDocumentType.RequestType.RequestTypeCode == "ORDER");
                    }
                    else
                    {
                        responsibleDealer = assignedCustLoc.Dealer;
                    }
                }

                if (responsibleDealer == null)
                {
                    // TODO: See clsOrderRequest lines 610-612 for how to handle
                    throw new Exception();
                }

                if (isDealerOrder)
                {
                    if (!string.IsNullOrEmpty(requestHeader.BillTo.Address.AddressId))
                    {
                        dealerAcctNbr = requestHeader.BillTo.Address.AddressId;
                    }
                    else
                    {
                        // TODO: Looks like this needs to reach out to Oracle DB to get acct number.  Review dcDealer.vb line 115 for guidance.
                        // dealerAcctNbr = GetItFromOracle(requestHeader.ShipTo.Address.AddressId)
                    }
                }

                var orderRouting = requestHeader.Extrinsics.FirstOrDefault(e => e.Name == "OrderRte")?.Value;
                var assignedCust = assignedCustLoc.Customer;
                var shipToId = xmlOrder.Request.OrderRequest.OrderRequestHeader.ShipTo.Address.AddressId;

                if (string.IsNullOrEmpty(orderRouting))
                {
                    orderRouting = assignedCust.DefaultOrderRoute;
                }

                if (IsDuplicateOrder(requestHeader.OrderId, isDealerOrder ? dealerAcctNbr : assignedCust.CustomerName,
                    shipToId))
                {
                    // TODO: see clsOrderRequest lines 635-637 for handling
                }
            }
        }

        private bool IsDuplicateOrder(string orderId, string customerName, string shipTo)
        {
            throw new NotImplementedException();
        }

        private void AssignDealerAndLocation(XmlOrder xmlOrder, out Dealer dealer, out CustomerLocation customerLocation)
        {
            try
            {
                var fromIdentity = xmlOrder.Header.From.Credential.Identity;

                var customer = _eCommerceRepository.Customers.FirstOrDefault(c => c.IdentityId == fromIdentity);
                if (customer == null)
                {
                    // TODO: See clsOrderRequest lines 199-201 for handling
                    throw new Exception();
                }

                var shipToId = xmlOrder.Request.OrderRequest.OrderRequestHeader.ShipTo.Address.AddressId;

                customerLocation = customer.CustomerLocations.FirstOrDefault(l =>
                    l.CustomerLocationCode == shipToId || l.PartCustomerLocationCode == shipToId);

                if (customerLocation == null)
                {
                    var shipToPostalCode = xmlOrder.Request.OrderRequest.OrderRequestHeader.ShipTo.Address.PostalAddress.PostalCode;

                    var newCustomerLocation = new CustomerLocation
                    {
                        CustomerLocationCode = shipToId,
                        ShipToPostalCode = shipToPostalCode
                    };

                    customer.CustomerLocations.Add(newCustomerLocation);

                    if (customer.Dealer != null)
                    {
                        newCustomerLocation.Dealer = customer.Dealer;
                    }
                    else
                    {
                        // TODO: See clsOrderRequest.vb lines 216-218 on how to handle
                        throw new Exception();
                    }

                    customerLocation = newCustomerLocation;
                }

                var headerExts = xmlOrder.Request.OrderRequest.OrderRequestHeader.Extrinsics;

                var orderRte = headerExts.FirstOrDefault(e => e.Name == "OrderRte")?.Value;
                var willCall = headerExts.FirstOrDefault(e => e.Value == "Will_Call")?.Value;

                var dealerAssignmentRequired = !(willCall != null && (orderRte == "DS" || orderRte == "WC"));
                if (dealerAssignmentRequired && customerLocation.Dealer == null)
                {
                    // TODO: See clsOrderRequest.vb lines 227-229 on how to handle
                    throw new Exception();
                }

                if (willCall != null)
                {
                    dealer = _eCommerceRepository.Dealers.FirstOrDefault(d =>
                        d.DealerCode == willCall && d.RequestDocumentType.RequestType.RequestTypeCode == "ORDER");
                }

                dealer = customerLocation.Dealer;
            }
            catch (Exception ex)
            {
                // TODO: See clsOrderRequest.vb lines 244-250 on how to handle exception
                throw ex;
            }
        }
        #endregion

        private void ProcessConfirmation(ProcessedRequest request)
        {
            throw new NotImplementedException();
        }

        private void ProcessShipmentNotice(ProcessedRequest request)
        {
            throw new NotImplementedException();
        }

        private void ProcessInvoice(ProcessedRequest request)
        {
            throw new NotImplementedException();
        }

        private void ProcessPunchoutSetup(ProcessedRequest request)
        {
            throw new NotImplementedException();
        }

        private void LogException(PostedRequest request)
        {
            // TODO: Implement
        }
    }
}
