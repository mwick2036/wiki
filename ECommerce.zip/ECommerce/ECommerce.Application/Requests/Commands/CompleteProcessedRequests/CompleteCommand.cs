﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using ECommerce.Application.Interfaces;
using ECommerce.Application.Requests.Commands.CompleteProcessedRequests.XmlObjects;
using ECommerce.Application.Requests.Commands.ReceivePostedRequests.Translators;
using ECommerce.Domain.Customers;
using ECommerce.Domain.Dealers;
using ECommerce.Domain.Orders;
using ECommerce.Domain.Requests;

namespace ECommerce.Application.Requests.Commands.CompleteProcessedRequests
{
    public class CompleteCommand : ICompleteCommand
    {
        private const string OrderRequestName = "OrderRequest";

        private readonly IECommerceRepository _eCommerceRepository;
        private readonly IExternalRepository _externalRepository;

        public CompleteCommand(IECommerceRepository eCommerceRepository, IExternalRepository externalRepository)
        {
            _eCommerceRepository = eCommerceRepository;
            _externalRepository = externalRepository;
        }

        public void Execute()
        {
            try
            {
                var processedRequests = _eCommerceRepository.ProcessedQueue.ToList();

                foreach (var request in processedRequests)
                {
                    var docType = request.ProcessedRequest.RequestTypeCode.TrimEnd();

                    switch (docType.ToUpper())
                    {
                        case "ORDER":
                            ProcessOrder(request.ProcessedRequest);
                            break;

                        case "CONFIRM":
                            ProcessConfirmation(request.ProcessedRequest);
                            break;

                        case "SHIPNOTICE":
                            ProcessShipmentNotice(request.ProcessedRequest);
                            break;

                        case "INVOICE":
                            ProcessInvoice(request.ProcessedRequest);
                            break;

                        case "POSETUP":
                            ProcessPunchoutSetup(request.ProcessedRequest);
                            break;
                    }
                }

                _eCommerceRepository.Save();
            }
            catch (Exception ex)
            {
                // TODO: See clsPrcsPrcsDocs.vb line 127+ for how to implement.
            }
        }

        #region Order Processing
        private void ProcessOrder(ProcessedRequest request)
        {
            if (request.RequestStatusCode != "N" && request.RequestStatusCode != "P")
            {
                // TODO: See clsOrderRequest.vb lines 138-140 to handle
                throw new Exception();
            }

            if (request.RequestTypeCode.TrimEnd().ToUpper() != "ORDER")
            {
                // TODO: See clsOrderRequest.vb lines 151-154 to handle
                throw new Exception();
            }

            XmlOrder xmlOrder;

            var serializer = new XmlSerializer(typeof(XmlOrder));
            using (TextReader reader = new StringReader(request.Contents))
            {
                xmlOrder = (XmlOrder) serializer.Deserialize(reader);
            }

            var isDealerOrder = false;

            var domain = xmlOrder.Header.From.Credential.Domain;

            if (domain != null && domain.ToLower() == "dealer")
                isDealerOrder = true;

            AssignDealerAndLocation(xmlOrder, out var assignedDealer, out var assignedCustLoc);

            var requestHeader = xmlOrder.Request.OrderRequest.OrderRequestHeader;
            var existingOrder = _eCommerceRepository
                .Orders
                .FirstOrDefault(o =>
                    o.CustomerOrderNumber == requestHeader.OrderId &&
                    o.CustomerName == assignedCustLoc.CustomerName);

            string GetExtrinsicValue(string name) => requestHeader.Extrinsics.FirstOrDefault(e => e.Name == name)?.Value;

            if (existingOrder != null)
            {
                // Update
            }
            else
            {
                // Add
                Dealer responsibleDealer;
                var dealerAcctNbr = string.Empty;

                if (isDealerOrder)
                {
                    const int tolasDealerId = 5;

                    responsibleDealer = _eCommerceRepository.Dealers.FirstOrDefault(d => d.Id == tolasDealerId);
                }
                else
                {
                    var orderRoute = GetExtrinsicValue("OrderRte");
                    var willCall = GetExtrinsicValue("Will_Call");

                    if ((orderRoute == "WC" || orderRoute == "DS") && willCall != null)
                    {
                        responsibleDealer = _eCommerceRepository.Dealers.FirstOrDefault(d =>
                            d.DealerCode == willCall && d.RequestDocumentType.RequestType.RequestTypeCode == "ORDER");
                    }
                    else if (assignedDealer.DealerCode.Contains("TOLAS") && !string.IsNullOrEmpty(assignedCustLoc.PartCustomerLocationCode))
                    {
                        responsibleDealer = _eCommerceRepository.Dealers.FirstOrDefault(d =>
                            d.DealerCode == assignedCustLoc.PartCustomerLocationCode && d.RequestDocumentType.RequestType.RequestTypeCode == "ORDER");
                    }
                    else
                    {
                        responsibleDealer = assignedCustLoc.Dealer;
                    }
                }

                if (responsibleDealer == null)
                {
                    // TODO: See clsOrderRequest.vb lines 610-612 for how to handle
                    throw new Exception();
                }

                if (isDealerOrder)
                {
                    dealerAcctNbr = !string.IsNullOrEmpty(requestHeader.BillTo.Address.AddressId)
                        ? requestHeader.BillTo.Address.AddressId
                        : GetExternalDealerAcctNbr(requestHeader.ShipTo.Address.AddressId);
                }

                var orderRouting = requestHeader.Extrinsics.FirstOrDefault(e => e.Name == "OrderRte")?.Value;
                var assignedCust = assignedCustLoc.Customer;
                var shipToId = requestHeader.ShipTo.Address.AddressId;

                if (string.IsNullOrEmpty(orderRouting))
                    orderRouting = assignedCust.DefaultOrderRoute;

                var assignedCustName = isDealerOrder ? dealerAcctNbr : assignedCust.CustomerName;

                if (IsDuplicateOrder(requestHeader.OrderId, assignedCustName, shipToId))
                {
                    // TODO: see clsOrderRequest lines 635-637 for handling
                }

                var newOrder = new Order
                {
                    CustomerName = assignedCustName,
                    CustomerLocationCode = shipToId,
                    CustomerOrderNumber = requestHeader.OrderId,
                    Status = "O",
                    Dealer = responsibleDealer,
                    OrderType = GetExtrinsicValue("OrderType"),
                    OrderRouting = orderRouting,
                    OrderLineItems = new List<OrderLineItem>(),
                };

                var shipToCountry = requestHeader.ShipTo.Address.CountryCode;
                var lineItems = xmlOrder.Request.OrderRequest.LineItems;
                
                foreach (var lineItem in lineItems)
                {
                    // TODO: Looks like in legacy there's an initialization of a wrapper object, not sure how to refactor (see 645 in clsOrderRequest.vb)

                    var partNumber = lineItem.ItemId.SupplierPartId;
                    var itemDetail = lineItem.ItemDetail;
                    var itemUnitPrice = itemDetail.UnitPrice.Price.Amount;

                    // Determine Item Unit Price if not supplied.
                    if (string.IsNullOrEmpty(itemUnitPrice.TrimEnd()) 
                        && assignedCust.DefaultPriceType != "NA"
                        && responsibleDealer.IsExternalDealer == "Y")
                    {
                        const int pricingSystemSuccess = 0;     //TODO: This might need to evolve into enum (see clsPartPrice.vb line 38)
                        const int pricingSystemError = 3;       //TODO: This might need to evolve into enum (see clsPartPrice.vb line 38)

                        var pricingStatus = GetPartUnitPrice(assignedCust, partNumber, out itemUnitPrice, out var itemUnitCurrency);

                        if (pricingStatus == pricingSystemError)
                        {
                            // TODO: See clsOrderRequest.vb lines 654-656 on how to handle
                            throw new Exception();
                        }

                        if (pricingStatus == pricingSystemSuccess)
                        {
                            // TODO: Not sure this assignment is needed, check if source changed when var's changed.
                            itemDetail.UnitPrice.Price.Amount = itemUnitPrice;
                            itemDetail.UnitPrice.Price.Currency = itemUnitCurrency;
                        }
                    }

                    var itecPart = false;

                    var marketMethod =
                        itemDetail.Extrinsics.FirstOrDefault(e => e.Name == "marketMethod")?.Value ??
                        (GetMarketMethod(partNumber, shipToCountry, out itecPart) ?? "DLR");

                    // TODO: Looks like from legacy code the owner is always NAVISTR but verify.
                    if (string.IsNullOrEmpty(itemDetail.Description) && itecPart)
                        itemDetail.Description = GetPartDescription(partNumber, "NAVISTR");

                    AddExtrinsic(itemDetail, "marketMethod", marketMethod);

                    if (GetExtrinsicValue("DocumentType")?.ToLower() != "return")
                    {
                        if (marketMethod.TrimEnd() == "DS")
                        {
                            var itemDcnCode = GetItemDcnCode(partNumber, shipToCountry);

                            if (!string.IsNullOrEmpty(itemDcnCode))
                                AddExtrinsic(itemDetail, "DCNCode", itemDcnCode);
                        }

                        var harmonizeCode = itecPart ? GetHarmonizeCode(partNumber, shipToCountry) : string.Empty;

                        if (!string.IsNullOrEmpty(harmonizeCode))
                            AddExtrinsic(itemDetail, "HTS", harmonizeCode);
                    }

                    newOrder.OrderLineItems.Add(new OrderLineItem
                    {
                        OrderLineNumber = lineItem.LineNumber,
                        PartNumber = partNumber,
                        Quantity = int.Parse(lineItem.Quantity),
                        UnitPrice = !string.IsNullOrEmpty(itemUnitPrice) ? decimal.Parse(itemUnitPrice) : 0,
                        PartDescription = itemDetail.Description,
                        PartCommodityGroupCode = itemDetail.Classification.Value,
                        PartUnitWeight = GetPartUnitWeight(partNumber)
                    });
                }

                request.RequestStatusCode = "P";
                request.Order = newOrder;
                request.RequestActionCode = "N";

                var stringwriter = new System.IO.StringWriter();
                serializer.Serialize(stringwriter, xmlOrder);

                request.Contents = stringwriter.ToString();

                // TODO: Need to also write to a log file, see clsOrderRequest line 699.
            }
        }

        private string GetExternalDealerAcctNbr(string addressId)
        {
            var customerLocation = _externalRepository.GetExternalCustomerLocation(addressId);

            return customerLocation?.CustomerAccountNumber;
        }

        private string GetHarmonizeCode(string partNumber, string shipToCountry)
        {
            var partCountry = _externalRepository.GetPartCountry(partNumber, new List<string> { shipToCountry, "USA" });

            if (partCountry == null)
                return null;

            if (!string.IsNullOrEmpty(partCountry.HarmonizeHeaderCode))
                return partCountry.HarmonizeHeaderCode;

            if (!string.IsNullOrEmpty(partCountry.HarmonizeSubHeaderCode))
                return partCountry.HarmonizeSubHeaderCode;

            if (!string.IsNullOrEmpty(partCountry.PartTariffCode))
                return partCountry.PartTariffCode;

            if (!string.IsNullOrEmpty(partCountry.HarmonizeStatReferralCode))
                return partCountry.HarmonizeStatReferralCode;

            return null;
        }

        private string GetItemDcnCode(string partNumber, string shipToCountry)
        {
            // TODO: Looks like some Tolas integration needed, review clsOrderRequest.vb line 1188
            // TODO: Replace test code with real thing.
            return "TestDcnCode";
        }

        private static void AddExtrinsic(ItemDetail itemDetail, string name, string value)
        {
            if (itemDetail.Extrinsics.All(e => e.Name != name))
            {
                itemDetail.Extrinsics.Add(new NameValue() { Name = name, Value = value });
            }
        }

        private decimal GetPartUnitWeight(string partNumber)
        {
            var partWeight = _externalRepository.GetPartWeight(partNumber);

            return partWeight == null ? 0 : decimal.Parse(partWeight.PartUnitWeight);
        }

        private string GetPartDescription(string partNumber, string partOwner)
        {
            var partDomain = _externalRepository.GetPartDomain(partNumber, partOwner);

            return partDomain?.PartDescription;
        }

        private string GetMarketMethod(string partNumber, string countryCode, out bool itecPart)
        {
            // TODO: I don't like how itecPart boolean gets set, should probably be its own method.
            itecPart = false;

            var partCountry = _externalRepository.GetPartCountry(partNumber, new List<string>{countryCode});

            if (partCountry != null)
                itecPart = true;

            return partCountry?.PartMarketMethodId;
        }

        private int GetPartUnitPrice(Customer customer, string partId, out string unitPrice, out string unitCurrency)
        {
            // TODO: It looks like this is coming from Oracle DB, review clsItemUnitPrice.vb line 58 for guidance.
            // TODO: Replace test code with real thing.
            unitPrice = "9.99";
            unitCurrency = "USD";

            return 0;
        }

        private bool IsDuplicateOrder(string orderId, string customerName, string shipTo)
        {
            // TODO: Replace below line with actual logic.
            return false;
        }

        private void AssignDealerAndLocation(XmlOrder xmlOrder, out Dealer dealer, out CustomerLocation customerLocation)
        {
            try
            {
                var fromIdentity = xmlOrder.Header.From.Credential.Identity;

                var customer = _eCommerceRepository.Customers.FirstOrDefault(c => c.IdentityId == fromIdentity);
                if (customer == null)
                {
                    // TODO: See clsOrderRequest lines 199-201 for handling
                    throw new Exception();
                }

                var shipToId = xmlOrder.Request.OrderRequest.OrderRequestHeader.ShipTo.Address.AddressId;

                customerLocation = customer.Locations.FirstOrDefault(l =>
                    l.CustomerLocationCode?.TrimEnd() == shipToId || l.PartCustomerLocationCode?.TrimEnd() == shipToId);

                if (customerLocation == null)
                {
                    var shipToPostalCode = xmlOrder.Request.OrderRequest.OrderRequestHeader.ShipTo.Address.PostalAddress.PostalCode;

                    var newCustomerLocation = new CustomerLocation
                    {
                        CustomerLocationCode = shipToId,
                        ShipToPostalCode = shipToPostalCode
                    };

                    customer.Locations.Add(newCustomerLocation);

                    if (customer.Dealer != null)
                    {
                        newCustomerLocation.Dealer = customer.Dealer;
                    }
                    else
                    {
                        // TODO: See clsOrderRequest.vb lines 216-218 on how to handle
                        throw new Exception();
                    }

                    customerLocation = newCustomerLocation;
                }

                var headerExts = xmlOrder.Request.OrderRequest.OrderRequestHeader.Extrinsics;

                var orderRte = headerExts.FirstOrDefault(e => e.Name == "OrderRte")?.Value;
                var willCall = headerExts.FirstOrDefault(e => e.Value == "Will_Call")?.Value;

                var dealerAssignmentRequired = !(willCall != null && (orderRte == "DS" || orderRte == "WC"));
                if (dealerAssignmentRequired && customerLocation.Dealer == null)
                {
                    // TODO: See clsOrderRequest.vb lines 227-229 on how to handle
                    throw new Exception();
                }

                if (willCall != null)
                {
                    dealer = _eCommerceRepository.Dealers.FirstOrDefault(d =>
                        d.DealerCode == willCall && d.RequestDocumentType.RequestType.RequestTypeCode == "ORDER");
                }

                dealer = customerLocation.Dealer;
            }
            catch (Exception ex)
            {
                // TODO: See clsOrderRequest.vb lines 244-250 on how to handle exception
                throw ex;
            }
        }
        #endregion

        private void ProcessConfirmation(ProcessedRequest request)
        {
            throw new NotImplementedException();
        }

        private void ProcessShipmentNotice(ProcessedRequest request)
        {
            throw new NotImplementedException();
        }

        private void ProcessInvoice(ProcessedRequest request)
        {
            throw new NotImplementedException();
        }

        private void ProcessPunchoutSetup(ProcessedRequest request)
        {
            throw new NotImplementedException();
        }

        private void LogException(PostedRequest request)
        {
            // TODO: Implement
        }
    }
}
