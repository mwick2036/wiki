﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.SqlServer.Server;

namespace ECommerce.Application.Requests.Commands.CompleteProcessedRequests.XmlObjects
{
    public class Credential
    {
        [XmlAttribute("domain")]
        public string Domain { get; set; }

        [XmlElement("Identity")]
        public string Identity { get; set; }

        [XmlElement("SharedSecret")]
        public string SharedSecret { get; set; }
    }

    public class Credentials
    {
        [XmlElement("Credential")]
        public Credential Credential { get; set; }

        [XmlElement("UserAgent")]
        public string UserAgent { get; set; }
    }

    public class Header
    {
        [XmlElement("From")]
        public Credentials From { get; set; }

        [XmlElement("To")]
        public Credentials To { get; set; }

        [XmlElement("Sender")]
        public Credentials Sender { get; set; }
    }

    public class Country
    {
        [XmlAttribute("isoCountryCode")]
        public string CountryCode { get; set; }

        [XmlText]
        public string CountryText { get; set; }
    }

    public class PostalAddress
    {
        [XmlElement("DeliverTo")]
        public List<string> DeliverTos { get; set; }

        [XmlElement("Street")]
        public string Street { get; set; }

        [XmlElement("City")]
        public string City { get; set; }

        [XmlElement("State")]
        public string State { get; set; }

        [XmlElement("PostalCode")]
        public string PostalCode { get; set; }

        [XmlElement("Country")]
        public Country Country { get; set; }
    }

    public class Telephone
    {
        [XmlElement("CountryCode")]
        public Country Country { get; set; }

        [XmlElement("AreaOrCityCode")]
        public string AreaCode { get; set; }

        [XmlElement("Number")]
        public string PhoneNumber { get; set; }
    }

    public class TelephoneNumber
    {
        [XmlElement("TelephoneNumber")]
        public Telephone Telephone { get; set; }
    }

    public class Address
    {
        [XmlAttribute("addressID")]
        public string AddressId { get; set; }

        [XmlAttribute("isoCountryCode")]
        public string CountryCode { get; set; }

        [XmlElement("Name")]
        public string Name { get; set; }

        [XmlElement("PostalAddress")]
        public PostalAddress PostalAddress { get; set; }

        [XmlElement("Phone")]
        public TelephoneNumber Phone { get; set; }

        [XmlElement("Fax")]
        public TelephoneNumber Fax { get; set; }
    }

    public class ToAddress
    {
        [XmlElement("Address")]
        public Address Address { get; set; }
    }

    public class Money
    {
        [XmlAttribute("currency")]
        public string Currency { get; set; }

        [XmlText]
        public string Amount { get; set; }
    }

    public class NameValue
    {
        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlText]
        public string Value { get; set; }
    }

    public class OrderRequestHeader
    {
        [XmlAttribute("orderDate")]
        public string OrderDate { get; set; }

        [XmlAttribute("orderID")]
        public string OrderId { get; set; }

        [XmlAttribute("orderType")]
        public string OrderType { get; set; }

        [XmlAttribute("orderVersion")]
        public string OrderVersion { get; set; }

        [XmlAttribute("type")]
        public string Type { get; set; }

        [XmlElement("Total")]
        public PriceCharge Total { get; set; }

        [XmlElement("ShipTo")]
        public ToAddress ShipTo { get; set; }

        [XmlElement("BillTo")]
        public ToAddress BillTo { get; set; }

        [XmlElement("Comments")]
        public string Comments { get; set; }

        [XmlElement("Extrinsic")]
        public List<NameValue> Extrinsics { get; set; }
    }

    public class SupplierPart
    {
        [XmlElement("SupplierPartID")]
        public string SupplierPartId { get; set; }
    }

    public class PriceCharge
    {
        [XmlElement("Money")]
        public Money Price { get; set; }
    }

    public class Segment
    {
        [XmlAttribute("type")]
        public string Type { get; set; }

        [XmlAttribute("id")]
        public string Id { get; set; }

        [XmlAttribute("description")]
        public string Description { get; set; }
    }

    public class Accounting
    {
        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlElement("Segment")]
        public Segment Segment { get; set; }
    }

    public class Distribution
    {
        [XmlElement("Accounting")]
        public Accounting Accounting { get; set; }

        [XmlElement("Charge")]
        public PriceCharge Charge { get; set; }
    }

    public class DomainValue
    {
        [XmlAttribute("domain")]
        public string Domain { get; set; }

        [XmlText]
        public string Value { get; set; }
    }

    public class ItemDetail
    {
        [XmlElement("UnitPrice")]
        public PriceCharge UnitPrice { get; set; }

        [XmlElement("Description")]
        public string Description { get; set; }

        [XmlElement("UnitOfMeasure")]
        public string UnitOfMeasure { get; set; }

        [XmlElement("Classification")]
        public DomainValue Classification { get; set; }

        [XmlElement("Extrinsic")]
        public NameValue Extrinsic { get; set; }
    }

    public class ItemOut
    {
        [XmlAttribute("lineNumber")]
        public string LineNumber { get; set; }

        [XmlAttribute("quantity")]
        public string Quantity { get; set; }

        [XmlAttribute("requestedDeliveryDate")]
        public string RequestedDeliveryDate { get; set; }

        [XmlElement("ItemID")]
        public SupplierPart ItemId { get; set; }

        [XmlElement("ItemDetail")]
        public ItemDetail ItemDetail { get; set; }

        [XmlElement("Distribution")]
        public Distribution Distribution { get; set; }
    }

    public class OrderRequest
    {
        [XmlElement("OrderRequestHeader")]
        public OrderRequestHeader OrderRequestHeader { get; set; }

        [XmlElement("ItemOut")]
        public List<ItemOut> LineItems { get; set; }
    }

    public class Request
    {
        [XmlAttribute("deploymentMode")]
        public string DeploymentMode { get; set; }

        [XmlElement("OrderRequest")]
        public OrderRequest OrderRequest { get; set; }
    }

    [XmlRoot("cXML")]
    public class XmlOrder
    {
        [XmlAttribute("payloadID")]
        public string PayloadId { get; set; }

        [XmlAttribute("timestamp")]
        public string Timestamp { get; set; }

        [XmlAttribute("version")]
        public string Version { get; set; }

        [XmlElement("Header")]
        public Header Header { get; set; }

        [XmlElement("Request")]
        public Request Request { get; set; }
    }
}
