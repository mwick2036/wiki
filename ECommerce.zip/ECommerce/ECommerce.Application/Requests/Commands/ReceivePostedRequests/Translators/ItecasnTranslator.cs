﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Application.Requests.Commands.ReceivePostedRequests.Translators
{
    public class ItecasnTranslator : ITranslator
    {
        private readonly string _xmlPrefix;
        private readonly string _xmlSuffix;

        public ItecasnTranslator()
        {
            var xsltLocation = ((NameValueCollection)ConfigurationManager.GetSection("FleetService/Locations"))["XLSTemplates"];

            _xmlPrefix = $"<?xml version='1.0' encoding='UTF-8'?><!DOCTYPE ITECASNFILE SYSTEM 'file://{xsltLocation}\\ITECASNFILE.dtd'>{Environment.NewLine}<ITECASNFILE>{Environment.NewLine}";
            _xmlSuffix = "</ITECASNFILE>";
        }

        public string Translate(string untranslated)
        {
            // TODO: Implement
            throw new NotImplementedException();
        }




    }
}
