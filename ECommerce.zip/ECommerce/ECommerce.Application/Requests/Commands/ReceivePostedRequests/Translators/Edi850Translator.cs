﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Application.Requests.Commands.ReceivePostedRequests.Translators
{
    public class Edi850Translator : ITranslator
    {
        private readonly string _xmlPrefix;
        private readonly string _xmlSuffix;

        public Edi850Translator()
        {
            var xsltLocation = ((NameValueCollection)ConfigurationManager.GetSection("FleetService/Locations"))["XLSTemplates"];

            _xmlPrefix = $"<?xml version='1.0' encoding='UTF-8'?><!DOCTYPE EDI850 SYSTEM 'file://{xsltLocation}\\EDI850.dtd'><EDI850>";
            _xmlSuffix = "</EDI850>";
        }

        public string Translate(string untranslated)
        {
            if (untranslated.IndexOf("!DOCTYPE", 0, StringComparison.Ordinal) != -1)
                return string.Empty;

            var translated = string.Empty;
            untranslated += Environment.NewLine;

            var ll = untranslated.IndexOf(Environment.NewLine, 0, StringComparison.Ordinal);

            while (untranslated.Length > 0)
            {
                if (ll == 0)
                    ll = untranslated.Length;

                var tLineKey = untranslated.Substring(0, 2);
                if (tLineKey == "10")
                {
                    if (translated.Length > 0)
                    {
                        translated += "</Order>";
                    }

                    translated += $"<Order customerId=\"{untranslated.Substring(36, 15).TrimEnd()}\">";
                }

                var tLine = untranslated.Substring(0, ll - 1).TrimEnd();
                if (tLine.Length > 0)
                {
                    translated += $"<TransactionLine id=\"{tLineKey}\">{tLine.Replace("&", "&amp;")}</TransactionLine>";
                }

                untranslated = untranslated.Substring(ll + 2);

                ll = untranslated.IndexOf(Environment.NewLine, 0, StringComparison.Ordinal);
                if (ll < 3)
                    untranslated = string.Empty;
            }

            translated = $"{_xmlPrefix}{translated}</Order>{_xmlSuffix}";

            return translated;
        }
    }
}
