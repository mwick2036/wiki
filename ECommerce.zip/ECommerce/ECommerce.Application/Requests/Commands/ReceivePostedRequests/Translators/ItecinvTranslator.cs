﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Application.Requests.Commands.ReceivePostedRequests.Translators
{
    public class ItecinvTranslator : ITranslator
    {
        public string Translate(string untranslated)
        {
            // TODO: Implement
            throw new NotImplementedException();
        }
    }
}
