﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Application.Requests.Commands.ReceivePostedRequests.Translators
{
    public class ItecackTranslator : ITranslator
    {
        private readonly string _xmlPrefix;
        private readonly string _xmlSuffix;

        public ItecackTranslator()
        {
            var xsltLocation = ((NameValueCollection)ConfigurationManager.GetSection("FleetService/Locations"))["XLSTemplates"];

            _xmlPrefix = $"<?xml version='1.0' encoding='UTF-8'?><!DOCTYPE ITECACKFILE SYSTEM 'file://{xsltLocation}\\ITECACKFILE.dtd'>{Environment.NewLine}<ITECACKFILE>{Environment.NewLine}";
            _xmlSuffix = "</ITECACKFILE>";
        }

        public string Translate(string untranslated)
        {
            var translated = string.Empty;

            if (untranslated.IndexOf("!DOCTYPE", 0, StringComparison.Ordinal) == -1 &&
                untranslated.IndexOf("DocumentID=", 0, StringComparison.Ordinal) > -1)
            {
                untranslated += Environment.NewLine;

                var ll = untranslated.IndexOf(Environment.NewLine, 0, StringComparison.Ordinal);

                while (untranslated.Length > 0)
                {
                    if (Convert.ToInt32(untranslated.Substring(0, 1)) <= 0)
                        continue;

                    if (ll == 0)
                        ll = untranslated.Length;

                    var tLine = untranslated.Substring(0, ll).TrimEnd().Substring(0, 1);

                    if (IsHeaderLine(tLine))
                    {
                        if (translated.Length > 0)
                            translated += $"</ITECACK>{Environment.NewLine}";

                        translated += BuildHeader(tLine);
                    }
                    else
                        translated += BuildItem(tLine);

                    untranslated = untranslated.Substring(ll + 2);

                    ll = untranslated.IndexOf(Environment.NewLine, 0, StringComparison.Ordinal);

                    if (ll < 3)
                        untranslated = string.Empty;
                }

                translated = $"{_xmlPrefix}{translated}</ITECACK>{_xmlSuffix}";
            }
            
            return translated;
        }

        private bool IsHeaderLine(string vData)
        {
            return vData.ToUpper().Substring(0, 1) == "A";
        }

        private string BuildHeader(string varLine)
        {
            var orderNumber = varLine.Substring(191, 9);
            return $"<ITECACK id='{orderNumber.TrimEnd()}' date='{DateTime.Now:yyyyMMdd}'><Header>{ReplaceSpecialCharacters(varLine.TrimEnd())}</Header>{Environment.NewLine}";
        }

        private string BuildItem(string varLine)
        {
            return $"<Item no='{varLine.Substring(1, 3)}' type='{varLine.Substring(0, 1)}'>{ReplaceSpecialCharacters(varLine.TrimEnd())}</Item>{Environment.NewLine}";
        }

        private string ReplaceSpecialCharacters(string varData)
        {
            return varData
                .Replace("&", "&amp;")
                .Replace("<", "&lt;")
                .Replace(">", "&gt;")
                .Replace("'", "&apos;")
                .Replace("\"", "&quot;");
        }
    }
}
