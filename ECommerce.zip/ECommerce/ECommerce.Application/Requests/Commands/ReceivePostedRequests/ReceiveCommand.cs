﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECommerce.Application.Interfaces;
using ECommerce.Application.Requests.Commands.ReceivePostedRequests.Translators;
using ECommerce.Domain.Requests;

namespace ECommerce.Application.Requests.Commands.ReceivePostedRequests
{
    public class ReceiveCommand : IReceiveCommand
    {
        private readonly IECommerceRepository _eCommerceRepository;

        public ReceiveCommand(IECommerceRepository eCommerceRepository)
        {
            _eCommerceRepository = eCommerceRepository;
        }

        public void Execute()
        {
            var postedRequests = _eCommerceRepository.GetPostedRequests();

            foreach (var postedRequest in postedRequests)
            {
                if (string.IsNullOrEmpty(postedRequest.Format))
                {
                    _eCommerceRepository.ErrorPostedRequest(postedRequest);
                    LogException(postedRequest);
                    continue;
                }

                var saveReceipt = ((NameValueCollection)ConfigurationManager.GetSection("FleetService/FileReceipts"))["Save"];
                if (saveReceipt == "Y")
                    _eCommerceRepository.BackupPostedRequest(postedRequest);

                var translatedRequest = TranslatePostedRequest(postedRequest);

                _eCommerceRepository.ReceivedRequests.Add(new ReceivedRequest()
                {
                    Contents = translatedRequest,
                    CreateDate = DateTime.Now,
                    SourceProgramId = "FILE-X"      // TODO: This may need to be variable depending on legacy biz logic
                });

                _eCommerceRepository.DeletePostedRequest(postedRequest);
            }

            _eCommerceRepository.Save();
        }

        private static string TranslatePostedRequest(PostedRequest request)
        {
            ITranslator translator;

            switch (request.Format.ToUpper())
            {
                case "EDI850":
                    translator = new Edi850Translator();
                    break;

                case "ITECACK":
                    translator = new ItecackTranslator();
                    break;

                case "ITECASN":
                    translator = new ItecasnTranslator();
                    break;

                case "ITECINV":
                    translator = new ItecinvTranslator();
                    break;

                default:
                    throw new Exception($"{request.Format} is not a supported Format");
            }

            return translator.Translate(request.Contents);
        }

        private void LogException(PostedRequest request)
        {
            // TODO: Implement
        }
    }
}
