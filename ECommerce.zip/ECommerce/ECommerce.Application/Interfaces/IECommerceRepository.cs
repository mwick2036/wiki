﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECommerce.Domain.Customers;
using ECommerce.Domain.Dealers;
using ECommerce.Domain.Orders;
using ECommerce.Domain.Requests;

namespace ECommerce.Application.Interfaces
{
    public interface IECommerceRepository
    {
        IDbSet<RequestSchemaMap> RequestSchemaMaps { get; set; }

        // Request tables
        IDbSet<ReceivedRequest> ReceivedRequests { get; set; }
        IDbSet<ReceiptQueue> ReceiptQueue { get; set; }

        IDbSet<ProcessedRequest> ProcessedRequests { get; set; }
        IDbSet<ProcessedQueue> ProcessedQueue { get; set; }
        IDbSet<RequestSendCredentials> RequestSendCredentials { get; set; }
        IDbSet<RequestType> RequestTypes { get; set; }

        IDbSet<Customer> Customers { get; set; }
        IDbSet<CustomerLocation> CustomerLocations { get; set; }
        IDbSet<Order> Orders { get; set; }
        IDbSet<Dealer> Dealers { get; set; }

        IDictionary<string, string> SchemaTemplates { get; set; }

        IList<PostedRequest> GetPostedRequests();
        void BackupPostedRequest(PostedRequest request);
        void ErrorPostedRequest(PostedRequest request);
        void DeletePostedRequest(PostedRequest request);

        void Save();
    }
}
