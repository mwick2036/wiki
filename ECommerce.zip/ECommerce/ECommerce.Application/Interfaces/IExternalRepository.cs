﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECommerce.Domain.Customers;
using ECommerce.Domain.Dealers;
using ECommerce.Domain.Orders;
using ECommerce.Domain.Requests;
using ECommerce.Domain.Parts;

namespace ECommerce.Application.Interfaces
{
    public interface IExternalRepository
    {
        PartCountry GetPartCountry(string partNumber, List<string> countryCodes);
        PartDomain GetPartDomain(string partNumber, string partOwner);
        PartWeight GetPartWeight(string partNumber);
        ExternalCustomerLocation GetExternalCustomerLocation(string locationId);
    }
}
