﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data.Entity;
using System.Data.Odbc;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using ECommerce.Application.Interfaces;
using ECommerce.Domain.Customers;
using ECommerce.Domain.Dealers;
using ECommerce.Domain.Orders;
using ECommerce.Domain.Parts;
using ECommerce.Domain.Requests;

namespace ECommerce.Repository
{
    public class ExternalRepository : IExternalRepository
    {
        private const string CwpConnStr = "DSN=DJ_CWP;Driver={Oracle RDB Driver};UID=yyyd275;PWD=xferbdpinv;";
        private const string PqpConnStr = "DSN=DJ_PQP;Driver={Oracle RDB Driver};UID=yyyd275;PWD=xferbdpinv;";
        private const string XrpConnStr = "DSN=DJ_XRP;Driver={Oracle RDB Driver};UID=yyyd275;PWD=xferbdpinv;";

        private readonly IList<PartCountry> _partCountries = new List<PartCountry>();
        private readonly IList<PartDomain> _partDomains = new List<PartDomain>();
        private readonly IList<ExternalCustomerLocation> _customerLocations = new List<ExternalCustomerLocation>();
        private readonly IList<PartWeight> _partWeights = new List<PartWeight>();

        public PartCountry GetPartCountry(string partNumber, List<string> countryCodes)
        {
            bool Cached(PartCountry p) => p.PartNumber == partNumber && countryCodes.Contains(p.CountryCode);

            if (_partCountries.Any(Cached))
                return _partCountries.First(Cached);

            using (var conn = new OdbcConnection(PqpConnStr))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = $"SELECT * FROM PETP020_CTRY_PART WHERE PART_25_NO = '{partNumber}' AND ST_PROV_CTRY IN ('{string.Join(",", countryCodes)}')";

                using (var reader = cmd.ExecuteReader())
                {
                    reader.Read();

                    if (!reader.HasRows)
                        return null;

                    var partCountry = new PartCountry
                    {
                        PartNumber = reader.GetString(4).TrimEnd(),
                        CountryCode = reader.GetString(5).TrimEnd(),
                        PartItemCode = reader.GetString(6).TrimEnd(),
                        DsPartItemCode = reader.GetString(15).TrimEnd(),
                        PartMarketMethodId = reader.GetString(17).TrimEnd(),
                        HarmonizeHeaderCode = reader.GetString(26).TrimEnd(),
                        HarmonizeSubHeaderCode = reader.GetString(27).TrimEnd(),
                        PartTariffCode = reader.GetString(28).TrimEnd(),
                        HarmonizeStatReferralCode = reader.GetString(29).TrimEnd()
                    };

                    _partCountries.Add(partCountry);

                    return partCountry;
                }
            }
        }

        public PartDomain GetPartDomain(string partNumber, string partOwner)
        {
            bool Cached(PartDomain p) => p.PartNumber == partNumber && p.PartOwner == partOwner;

            if (_partDomains.Any(Cached))
                return _partDomains.First(Cached);

            using (var conn = new OdbcConnection(XrpConnStr))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = $"SELECT * FROM XRTP070_PRT_DOMAIN WHERE PART_25_NO = '{partNumber}' AND PART_NO_OWNR_ID = '{partOwner}'";

                using (var reader = cmd.ExecuteReader())
                {
                    reader.Read();

                    if (!reader.HasRows)
                        return null;

                    var partDomain = new PartDomain
                    {
                        PartNumber = reader.GetString(5).TrimEnd(),
                        PartOwner = reader.GetString(6).TrimEnd(),
                        PartDescription = reader.GetString(0).TrimEnd()
                    };

                    _partDomains.Add(partDomain);

                    return partDomain;
                }
            }
        }

        public PartWeight GetPartWeight(string partNumber)
        {
            bool Cached(PartWeight p) => p.PartNumber == partNumber;

            if (_partWeights.Any(Cached))
                return _partWeights.First(Cached);

            using (var conn = new OdbcConnection(PqpConnStr))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = $"SELECT * FROM PQTP140_WGHT_MEAS WHERE PART_25_NO = '{partNumber}'";

                using (var reader = cmd.ExecuteReader())
                {
                    reader.Read();

                    if (!reader.HasRows)
                        return null;

                    var partWeight = new PartWeight
                    {
                        PartNumber = reader.GetString(4).TrimEnd(),
                        PartUnitWeight = reader.GetString(16).TrimEnd()
                    };

                    _partWeights.Add(partWeight);

                    return partWeight;
                }
            }
        }

        public ExternalCustomerLocation GetExternalCustomerLocation(string locationId)
        {
            bool Cached(ExternalCustomerLocation l) => l.CustomerLocationNumber == locationId;

            if (_customerLocations.Any(Cached))
                return _customerLocations.First(Cached);

            using (var conn = new OdbcConnection(CwpConnStr))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = $"SELECT * FROM CWTP030_CUST_LOC WHERE PART_CUST_LOC_NO = '{locationId}'";

                using (var reader = cmd.ExecuteReader())
                {
                    reader.Read();

                    if (!reader.HasRows)
                        return null;

                    var customerLocation = new ExternalCustomerLocation
                    {
                        CustomerLocationNumber = reader.GetString(0).TrimEnd(),
                        ShipToName = reader.GetString(12).TrimEnd(),
                        ShipToAddress = reader.GetString(13).TrimEnd(),
                        ShipToAddressLine2 = reader.GetString(14).TrimEnd(),
                        ShipToCity = reader.GetString(15).TrimEnd(),
                        ShipToState = reader.GetString(16).TrimEnd(),
                        ShipToPostalCode = reader.GetString(17).TrimEnd(),
                        ShipToCountry = reader.GetString(18).TrimEnd(),
                        FleetChargeNumber = reader.GetString(52).TrimEnd(),
                        ProfileLocationStatusCode = reader.GetString(44).TrimEnd(),
                        CustomerAccountNumber = reader.GetString(1).TrimEnd()
                    };

                    _customerLocations.Add(customerLocation);

                    return customerLocation;
                }
            }
        }
    }
}
