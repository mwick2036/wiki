﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data.Entity;
using System.IO;
using System.Linq;
using ECommerce.Application.Interfaces;
using ECommerce.Domain.Customers;
using ECommerce.Domain.Dealers;
using ECommerce.Domain.Orders;
using ECommerce.Domain.Requests;

namespace ECommerce.Repository
{
    public class ECommerceRepository : DbContext, IECommerceRepository
    {
        public IDictionary<string, string> SchemaTemplates { get; set; }
        public IDbSet<RequestSchemaMap> RequestSchemaMaps { get; set; }
        public IDbSet<ReceivedRequest> ReceivedRequests { get; set; }
        public IDbSet<ReceiptQueue> ReceiptQueue { get; set; }
        public IDbSet<ProcessedRequest> ProcessedRequests { get; set; }
        public IDbSet<ProcessedQueue> ProcessedQueue { get; set; }
        public IDbSet<RequestSendCredentials> RequestSendCredentials { get; set; }
        public IDbSet<RequestType> RequestTypes { get; set; }
        public IDbSet<Customer> Customers { get; set; }
        public IDbSet<CustomerLocation> CustomerLocations { get; set; }
        public IDbSet<Order> Orders { get; set; }
        public IDbSet<Dealer> Dealers { get; set; }

        public ECommerceRepository() : base(SingleConnection.ConString)
        {
            SchemaTemplates = new Dictionary<string, string>();

            var cnfLocations = (NameValueCollection)ConfigurationManager.GetSection("FleetService/Locations");
            var templateLocation = cnfLocations["XLSTemplates"];
            var templateDirectory = new DirectoryInfo(templateLocation);

            var templateFiles = templateDirectory.GetFiles();

            foreach (var templateFile in templateFiles)
            {
                SchemaTemplates.Add(templateFile.Name, File.ReadAllText(templateFile.FullName));
            }
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Customer>().HasMany(c => c.Locations).WithRequired(l => l.Customer);
            modelBuilder.Entity<Order>().HasMany(o => o.OrderLineItems).WithRequired(l => l.Order);

            //modelBuilder.Configurations.Add(new DiaOrderConfiguration());
            //modelBuilder.Configurations.Add(new CumminsOrderConfiguration());
        }

        public IList<PostedRequest> GetPostedRequests()
        {
            var cnfLocations = (NameValueCollection)ConfigurationManager.GetSection("FleetService/Locations");
            var postLocation = cnfLocations["File Post"];
            var postDirectory = new DirectoryInfo(postLocation);

            var postFiles = postDirectory.GetFiles();

            return postFiles.Select(postFile => new PostedRequest()
                {
                    Name = postFile.FullName,
                    Format = postFile.Name.Split('_')[0],
                    Contents = File.ReadAllText(postFile.FullName)
                })
                .ToList();
        }

        public void BackupPostedRequest(PostedRequest request)
        {
            // TODO: Implement
        }

        public void ErrorPostedRequest(PostedRequest request)
        {
            // TODO: Implement
        }

        public void DeletePostedRequest(PostedRequest request)
        {
            // TODO: Implement
        }

        public void Save()
        {
            this.SaveChanges();
        }
    }
}
