﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Repository
{
    public class SingleConnection
    {
        private SingleConnection() { }
        private static SingleConnection _consString = null;
        private string _string = null;

        public static string ConString
        {
            get
            {
                if (_consString == null)
                {
                    _consString = new SingleConnection { _string = SingleConnection.Connect() };
                    return _consString._string;
                }

                return _consString._string;
            }
        }

        public static string Connect()
        {
            var cnfSqlConnection = (NameValueCollection)ConfigurationManager.GetSection("FleetService/SQLSession");

            //Build an SQL connection string
            var sqlString = new SqlConnectionStringBuilder()
            {
                DataSource = cnfSqlConnection["Server"], // Server name
                InitialCatalog = cnfSqlConnection["Database"],  //Database
                UserID = cnfSqlConnection["User"],         //Username
                Password = cnfSqlConnection["Password"]  //Password
            };

            return sqlString.ConnectionString;
            //Build an Entity Framework connection string
            //var entityString = new EntityConnectionStringBuilder()
            //{
            //    Provider = "System.Data.SqlClient",
            //    Metadata = "res://*/testModel.csdl|res://*/testModel.ssdl|res://*/testModel.msl",
            //    ProviderConnectionString = sqlString.ToString()
            //};

            //return entityString.ConnectionString;
        }
    }
}
