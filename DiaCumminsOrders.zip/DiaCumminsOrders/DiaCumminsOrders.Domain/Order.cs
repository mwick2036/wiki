﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiaCumminsOrders.Domain
{
    public class Order
    {
        public int Id { get; set; }
        public string DistributorCode { get; set; }
        public string IntegrationId { get; set; }
        public string DealerCode { get; set; }
        public string OrderType { get; set; }
        public string Currency { get; set; }
        public string DeliveryMethod { get; set; }
        public string ShipVia { get; set; }
        public string ShipToName { get; set; }
        public string PoNumber { get; set; }
        public string PartNumber { get; set; }
        public int Quantity { get; set; }
        public decimal UnitNetPrice { get; set; }
        public DateTime? SubmitDate { get; set; }
        public DateTime? LastRetryDate { get; set; }
        public int? Retries { get; set; }
    }
}
