﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiaCumminsOrders.Application.Interfaces;
using DiaCumminsOrders.Domain;

namespace DiaCumminsOrders.Persistence
{
    public class DatabaseService: DbContext, IDatabaseService
    {
        public IDbSet<Order> Orders { get; set; }
        public void Save()
        {
            this.SaveChanges();
        }

        public DatabaseService() : base("Navistar")
        {
            Database.SetInitializer<DatabaseService>(null);
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Configurations.Add(new OrderConfiguration());
        }
    }
}
