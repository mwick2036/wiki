﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiaCumminsOrders.Application.Interfaces;
using DiaCumminsOrders.Domain;

namespace DiaCumminsOrders.Application.Orders.Commands.SubmitOrders
{
    public class SubmitOrdersCommand : ISubmitOrdersCommand
    {
        private readonly IDatabaseService _database;
        private readonly ICumminsService _cummins;

        public SubmitOrdersCommand(IDatabaseService database, ICumminsService cummins)
        {
            _database = database;
            _cummins = cummins;
        }

        public void Execute()
        {
            var orders = _database.Orders.ToList();

            _cummins.SubmitOrders(orders);
        }
    }
}
