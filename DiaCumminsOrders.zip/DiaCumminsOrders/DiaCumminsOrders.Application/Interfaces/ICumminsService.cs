﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiaCumminsOrders.Domain;

namespace DiaCumminsOrders.Application.Interfaces
{
    public interface ICumminsService
    {
        void SubmitOrders(IList<Order> orders);
    }
}
