﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiaCumminsOrders.Application.Interfaces;
using DiaCumminsOrders.Domain;
using DiaCumminsOrders.Infrastructure.Network;

namespace DiaCumminsOrders.Infrastructure.Cummins
{
    public class CumminsService : ICumminsService
    {
        private readonly IWebClientWrapper _client;

        public CumminsService(IWebClientWrapper client)
        {
            _client = client;
        }

        public void SubmitOrders(IList<Order> orders)
        {
            // TODO: Cycle thru orders, in batches of 99, and post to Cummins API endpoint with JSON in request body

            throw new NotImplementedException();
        }
    }
}
