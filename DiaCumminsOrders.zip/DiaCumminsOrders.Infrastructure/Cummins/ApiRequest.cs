﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiaCumminsOrders.Infrastructure.Cummins
{
    internal static class Sender
    {
        public static string MessageID => "123";
        public static string ServiceName => "DealerComm";
        public static string SenderID => "SF";

    }

    internal static class Header
    {
        public Sender Sender;
    }

    public class ApiRequest
    {

    }
}
