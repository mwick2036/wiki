﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using DiaCumminsOrders.Application.Interfaces;
using DiaCumminsOrders.Domain;
using DiaCumminsOrders.Infrastructure.Network;

namespace DiaCumminsOrders.Infrastructure.Cummins
{
    public class Service : ICumminsService
    {
        private readonly IWebClientWrapper _client;
        private readonly string _cumminsApiEndpoint;

        public Service(IWebClientWrapper client)
        {
            _client = client;
            _cumminsApiEndpoint = ConfigurationManager.AppSettings["CumminsApiEndpoint"];
        }

        // TODO: Consider getting this from config file
        public int MaxOrders => 100;

        public bool SubmitOrders(string poNumber, IList<Order> orders)
        {
            // Orders to be batched in 100 by caller, throw error if not
            if (orders.Count > MaxOrders)
            {
                throw new ArgumentException($"Order count cannot exceed {MaxOrders} line items", nameof(orders));
            }

            var request = BuildApiRequest(poNumber, orders);
            var jsonRequest = new JavaScriptSerializer().Serialize(request);

            return _client.Post(_cumminsApiEndpoint, jsonRequest);

            //return true;
        }

        public object BuildApiRequest(string poNumber, IList<Order> orders)
        {
            var firstOrder = orders.First();

            return new
            {
                Header = new
                {
                    Sender = new
                    {
                        MessageID = "123",
                        ServiceName = "DealerComm",
                        SenderID = "SF"
                    },
                    Target = new
                    {
                        TargetID = string.Empty // TODO: This needs to be DistributorCode, waiting for answer on this
                    }
                },
                DataArea = new
                {
                    DealerCode = firstOrder.DealerCode,
                    DistributorCode = string.Empty, // TODO: This needs to be DistributorCode, waiting for answer on this
                    RegionCode = string.Empty, 
                    OrderHeader = new
                    {
                        OrderId = string.Empty,
                        IntegrationId = string.Empty, // TODO: Open question about where this comes from: firstOrder.IntegrationId?
                        OrderStatus = "Submitted",
                        OrderType = firstOrder.OrderType,
                        DealerCode = firstOrder.DealerCode,
                        OrderTotal = orders.Sum(o => o.UnitNetPrice),
                        TotalLines = orders.Count,
                        CreationDate = DateTime.Now,
                        Currency = firstOrder.Currency, // TODO: Currency needs to be derived from Country Code
                        DeliveryMethod = string.Empty,
                        ContactPhone = string.Empty,
                        ContactName = string.Empty,
                        Attribute1 = "0",
                        ShipVia = firstOrder.ShipVia,
                        ShipToName = firstOrder.ShipToName,
                        PONumber = poNumber,
                        FutureDate = string.Empty,
                        UserComments = string.Empty, // TODO: Open question about whether this needs to be passed
                        CompanyId = string.Empty,
                        DivisionId = string.Empty,
                        DistributorCode = string.Empty, // TODO: This needs to be DistributorCode, waiting for answer on this
                        Locale = "en_US",
                        PCID = "22",
                        BranchName = string.Empty,
                        ConfirmationNumber = string.Empty,
                        RSControlNumber = string.Empty,
                        EngineSerialNumber = string.Empty,
                        PaymentType = string.Empty,
                        SuggestionId = string.Empty,
                        PickUp = string.Empty,  // TODO: Outstanding question about whether this needs to be set or not
                        OnHold = string.Empty,
                        AllocationDisplay = string.Empty,
                        RDCPONumber = string.Empty,
                        POAcknowlegementDate = string.Empty,
                        CorporateBranchNumber = string.Empty,
                        ShippingAddress = new 
                        {
                            LineOne = string.Empty,
                            AddressId = string.Empty,
                            LineTwo = string.Empty,
                            CityName = string.Empty,
                            PostalCode = string.Empty,
                            StateName = string.Empty,
                            CountryCode = string.Empty
                        }
                    },
                    OrderLine = new
                    {
                        PartNumbers = new
                        {
                            Part = GetParts(orders)
                        }
                    }
                }
            };
        }

        private static List<object> GetParts(IEnumerable<Order> orders)
        {
            var parts = new List<object>();

            foreach (var order in orders)
            {
                parts.Add(new
                {
                    PartNumber = order.PartNumber,
                    LineId = string.Empty,
                    LineNo = string.Empty,
                    PartDescription = string.Empty,
                    PartQuantity = order.Quantity,
                    UnitNetPrice = order.UnitNetPrice,
                    TotalPrice = order.Quantity * order.UnitNetPrice,
                    ItemNumber = string.Empty,
                    ProductCode = string.Empty,
                    NonEnterprise = string.Empty,
                    Attribute1 = string.Empty,
                    Attribute2 = string.Empty
                });
            }

            return parts;
        }
    }
}
