﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiaCumminsOrders.Domain;

namespace DiaCumminsOrders.Application.Orders.Commands.SubmitOrders
{
    public interface ISubmitOrdersCommand
    {
        void Execute();
    }
}
