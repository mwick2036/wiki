﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiaCumminsOrders.Application.Interfaces;
using DiaCumminsOrders.Domain;

namespace DiaCumminsOrders.Application.Orders.Commands.SubmitOrders
{
    public class SubmitOrdersCommand : ISubmitOrdersCommand
    {
        private readonly IDatabaseService _database;
        private readonly ICumminsService _cummins;

        public SubmitOrdersCommand(IDatabaseService database, ICumminsService cummins)
        {
            _database = database;
            _cummins = cummins;
        }

        public void Execute()
        {
            // Get unsubmitted orders, grouped by PO and organized as dictionary (key = PoNumber, value = line items for PO).
            var ordersByPo = _database.Orders
                .Where(o => o.SubmitDate == null)
                .GroupBy(o => o.PoNumber)
                .ToDictionary(go => go.Key, go => go.ToList());

            foreach (var orderByPo in ordersByPo)
            {
                var poNumber = orderByPo.Key;
                var poOrders = orderByPo.Value;
                var poSuffix = 0;

                for (var i = 0; i < poOrders.Count; i += _cummins.MaxOrders)
                {
                    var orderBatch = poOrders.Take(_cummins.MaxOrders).Skip(i).ToList();
                    var success = _cummins.SubmitOrders($"{poNumber}-{++poSuffix}", orderBatch);

                    foreach (var order in orderBatch)
                    {
                        if (success)
                        {
                            // TODO: Determine if Cummins PO number (suffixed) needs to be added as well
                            order.SubmitDate = DateTime.Now;
                        }
                        else
                        {
                            if (order.Retries.HasValue)
                            {
                                order.LastRetryDate = DateTime.Now;
                                order.Retries += 1;
                            }
                            else
                            {
                                order.Retries = 0;
                            }
                        }
                    }
                }
            }

            // Send in batches of Cummins MaxOrders per API call
            //for (var i = 0; i < ordersByPo.Count(); i += _cummins.MaxOrders)
            //{
            //    var orderBatch = ordersByPo.Take(_cummins.MaxOrders).Skip(i).ToList();
            //    var success = _cummins.SubmitOrders(orderBatch);

            //    foreach (var order in orderBatch)
            //    {
            //        if (success)
            //        {
            //            order.SubmitDate = DateTime.Now;
            //        }
            //        else
            //        {
            //            if (order.Retries.HasValue)
            //            {
            //                order.LastRetryDate = DateTime.Now;
            //                order.Retries += 1;
            //            }
            //            else
            //            {
            //                order.Retries = 0;
            //            }
            //        }
            //    }
            //}

            _database.Save();
        }
    }
}
